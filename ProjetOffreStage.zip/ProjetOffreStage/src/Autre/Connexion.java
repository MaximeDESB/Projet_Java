package Autre;

import java.sql.DriverManager;

import com.mysql.jdbc.Connection;

public class Connexion {

	static Connection con;
	static String adresse = "jdbc:mysql://localhost:3306/gestionstage?autoReconnect=true&useSSL=false";
	static String login = "root";
	static String mdp = "root";

	public static Connection connect() {
		try {
			if (con == null) {
				con = (Connection) DriverManager.getConnection(adresse, login, mdp);
				System.out.println("connexion r�ussi");
			}
		} catch (Exception e) {
			System.out.println("non connect�");
		}
		return con;
	}
}
