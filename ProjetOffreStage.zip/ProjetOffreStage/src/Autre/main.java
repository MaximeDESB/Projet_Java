package Autre;

import IHM.Acceuil.Acceuil_unlog;

public class main {

	// Acceuil unlog = page d'acceuil (mode non connect�)
	
	public static void main(String[] args) {
		
		new Acceuil_unlog();
}}