package Autre;

import java.sql.Date;

public class ChangerDate {
	
	public ChangerDate() {}
	
	@SuppressWarnings("deprecation")
	public static String toString(java.util.Date date)
	{
		
		int jour = date.getDate();
		int mois = date.getMonth()+1;
		int annee = date.getYear() + 1900;
		String month = null;
		
		switch (mois)
		{
		case 1:
			month = "Janvier";
			break;
		case 2:
			month = "F�vrier";
			break;
		case 3:
			month = "Mars";
			break;
		case 4:
			month = "Avril";
			break;
		case 5:
			month = "Mai";
			break;
		case 6:
			month = "Juin";
			break;
		case 7:
			month = "Juillet";
			break;
		case 8:
			month = "Aout";
			break;
		case 9:
			month = "Septembre";
			break;
		case 10:
			month = "Octobre";
			break;
		case 11:
			month = "Novembre";
			break;
		case 12:
			month = "D�cembre";
			break;
		}
		
		return jour+" "+month+" "+annee;
		
	}
	
	@SuppressWarnings("deprecation")
	public static String toStringModifier (Date date)
	{
		int jour = date.getDate();
		int mois = date.getMonth()+1;
		int annee = date.getYear() + 1900;
		String s_jour;
		String s_mois;
		
		if (jour < 10) s_jour = "0"+Integer.toString(jour);
		else s_jour = Integer.toString(jour);
		if (mois < 10) s_mois = "0"+Integer.toString(mois);
		else s_mois = Integer.toString(mois);
		
		return s_jour+"/"+s_mois+"/"+annee;
		
	}

}
