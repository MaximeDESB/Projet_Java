package Objet;

public class Administrateur {
	private int id;
	private int idSecurite;

	public Administrateur(int id, int idSecurite) {
		super();
		this.id = id;
		this.idSecurite = idSecurite;
	}

	public Administrateur() {
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getIdSecurite() {
		return idSecurite;
	}

	public void setIdSecurite(int idSecure) {
		this.idSecurite = idSecure;
	}

}
