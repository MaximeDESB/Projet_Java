package Objet;

public class Entreprise {

	private int id;
	private String nom;
	private int idAdresse;
	private String email;
	private String tel;
	private int idSecteur;
	private int idSecurite;
	private String logo;

	public Entreprise(int id, String nom, int idAdresse, String email, String tel, int idSecteur, int idSecurite,
			String logo) {
		super();
		this.id = id;
		this.nom = nom;
		this.idAdresse = idAdresse;
		this.email = email;
		this.tel = tel;
		this.idSecteur = idSecteur;
		this.idSecurite = idSecurite;
		this.logo = logo;
	}

	public Entreprise(String nom, int idAdresse, String email, String tel, int idSecteur, int idSecurite) {
		super();
		this.nom = nom;
		this.idAdresse = idAdresse;
		this.email = email;
		this.tel = tel;
		this.idSecteur = idSecteur;
		this.idSecurite = idSecurite;
	}

	public Entreprise() {
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public int getIdAdresse() {
		return idAdresse;
	}

	public void setIdAdresse(int idAdresse) {
		this.idAdresse = idAdresse;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public int getIdSecteur() {
		return idSecteur;
	}

	public void setIdSecteur(int idSecteur) {
		this.idSecteur = idSecteur;
	}

	public int getIdSecurite() {
		return idSecurite;
	}

	public void setIdSecurite(int idSecurite) {
		this.idSecurite = idSecurite;
	}

	public String getLogo() {
		return logo;
	}

	public void setLogo(String logo) {
		this.logo = logo;
	}

}
