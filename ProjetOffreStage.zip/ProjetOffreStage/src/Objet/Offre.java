package Objet;

import java.sql.Date;

public class Offre {

	private int id;
	private int idDomaine;
	private String nomOffre;
	private Date dateDebut;
	private int duree;
	private String description;
	private int idEntreprise;

	public Offre(int idDomaine, String nomOffre, Date dateDebut, int duree, String description, int idEntreprise) {
		super();
		this.idDomaine = idDomaine;
		this.nomOffre = nomOffre;
		this.dateDebut = dateDebut;
		this.duree = duree;
		this.description = description;
		this.idEntreprise = idEntreprise;
	}

	public Offre(int id, int idDomaine, String nomOffre, Date dateDebut, int duree, String description,
			int idEntreprise) {
		super();
		this.id = id;
		this.idDomaine = idDomaine;
		this.nomOffre = nomOffre;
		this.dateDebut = dateDebut;
		this.duree = duree;
		this.description = description;
		this.idEntreprise = idEntreprise;
	}

	@SuppressWarnings("deprecation")
	public Offre(int idEntreprise) {
		this.nomOffre = "Nom de L'offre";
		this.dateDebut = new Date(0, 0, 0);
		this.duree = 0;
		this.idEntreprise = idEntreprise;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getIdDomaine() {
		return idDomaine;
	}

	public void setIdDomaine(int idDomaine) {
		this.idDomaine = idDomaine;
	}

	public String getNomOffre() {
		return nomOffre;
	}

	public void setNomOffre(String nomOffre) {
		this.nomOffre = nomOffre;
	}

	public Date getDateDebut() {
		return dateDebut;
	}

	public void setDateDebut(Date dateDebut) {
		this.dateDebut = dateDebut;
	}

	public int getDuree() {
		return duree;
	}

	public void setDuree(int duree) {
		this.duree = duree;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getIdEntreprise() {
		return idEntreprise;
	}

	public void setIdEntreprise(int idEntreprise) {
		this.idEntreprise = idEntreprise;
	}

}
