package Objet;

public class Stage {

	private int id;
	private int idEtudiant;
	private int idOffre;
	private String statut;
	private String motivation;

	public Stage(int idEtudiant, int idOffre, String statut) {
		super();
		this.idEtudiant = idEtudiant;
		this.idOffre = idOffre;
		this.statut = statut;
	}

	public Stage(int id, int idEtudiant, int idOffre, String statut, String motivation) {
		super();
		this.id = id;
		this.idEtudiant = idEtudiant;
		this.idOffre = idOffre;
		this.statut = statut;
		this.motivation = motivation;
	}

	public Stage(int idEtudiant, int idOffre, String statut, String mot) {
		super();

		this.idEtudiant = idEtudiant;
		this.idOffre = idOffre;
		this.statut = statut;
		this.motivation = mot;
	}

	public String getMotivation() {
		return motivation;
	}

	public void setMotivation(String motivation) {
		this.motivation = motivation;
	}

	public Stage() {
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getIdEtudiant() {
		return idEtudiant;
	}

	public void setIdEtudiant(int idEtudiant) {
		this.idEtudiant = idEtudiant;
	}

	public int getIdOffre() {
		return idOffre;
	}

	public void setIdOffre(int idOffre) {
		this.idOffre = idOffre;
	}

	public String getStatut() {
		return statut;
	}

	public void setStatut(String statut) {
		this.statut = statut;
	}

}
