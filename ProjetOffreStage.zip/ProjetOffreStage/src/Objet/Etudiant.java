package Objet;

import DAO.StageDAO;

public class Etudiant {

	private int id;
	private String nom;
	private String prenom;
	private String email;
	private int idAdresse;
	private int idSecurite;
	private String pathCv;
	private boolean nouveauStage;

	public String getPathCv() {
		return pathCv;
	}

	public void setPathCv(String pathCv) {
		this.pathCv = pathCv;
	}

	public boolean getNouveauStage() {
		return nouveauStage;
	}

	public void setNouveauStage(boolean nouveauStage) {
		this.nouveauStage = nouveauStage;
	}

	public Etudiant(int id, String nom, String prenom, String email, int idAdresse, int idSecurite) {
		super();
		this.id = id;
		this.nom = nom;
		this.prenom = prenom;
		this.email = email;
		this.idAdresse = idAdresse;
		this.idSecurite = idSecurite;
	}

	public Etudiant(String nom, String prenom, String email, int idAdresse, int idSecurite) {
		super();
		this.nom = nom;
		this.prenom = prenom;
		this.email = email;
		this.idAdresse = idAdresse;
		this.idSecurite = idSecurite;
	}

	public Etudiant(String nom, String prenom, String email, int idAdresse, int idSecurite, String p) {
		super();
		this.id = id;
		this.nom = nom;
		this.prenom = prenom;
		this.email = email;
		this.idAdresse = idAdresse;
		this.idSecurite = idSecurite;
		this.pathCv = p;
	}

	public Etudiant(int id, String nom, String prenom, String email, int idAdresse, int idSecurite, String p,
			boolean nouveauStage) {
		super();
		this.id = id;
		this.nom = nom;
		this.prenom = prenom;
		this.email = email;
		this.idAdresse = idAdresse;
		this.idSecurite = idSecurite;
		this.pathCv = p;
		this.nouveauStage = nouveauStage;
	}

	public Etudiant() {

	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getIdAdresse() {
		return idAdresse;
	}

	public void setIdAdresse(int idAdresse) {
		this.idAdresse = idAdresse;
	}

	public int getIdSecurite() {
		return idSecurite;
	}

	public void setIdSecurite(int idSecurite) {
		this.idSecurite = idSecurite;
	}

	public boolean postuler(Offre offre, String motiv) {
		StageDAO stagDAO = new StageDAO();
		if (stagDAO.find_double_id(this.getId(), offre.getId()) == null) {
			Stage stage = new Stage(this.getId(), offre.getId(), "En attente", motiv);
			stagDAO.create(stage);
			return true;
		}
		return false;
	}

}
