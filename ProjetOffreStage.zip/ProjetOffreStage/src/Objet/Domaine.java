package Objet;

public class Domaine {

	private int id;
	private String nom;

	public Domaine(int id2, String nom) {
		super();
		this.id = id2;
		this.nom = nom;
	}

	public Domaine() {
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

}
