package IHM.JTable;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import DAO.*;
import IHM.Creer.CreerEntreprisePanel;
import Objet.*;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class JTableEntreprise extends JDialog {

	JTable Jtableau;
	EntrepriseDAO entrDAO = new EntrepriseDAO();
	AdresseDAO adreDAO = new AdresseDAO();
	OffreDAO offrDAO = new OffreDAO();
	DomaineDAO domaDAO = new DomaineDAO();
	StageDAO stageDao = new StageDAO();
	SecuriteDAO secuDAO = new SecuriteDAO();

	JPanel panelBouton;
	JButton ajouter;
	JButton supprimer;

	JTableModel tableModel;
	ArrayList<Entreprise> listEntr;
	Object[][] donnees;
	BorderLayout layout = new BorderLayout();
	private final String[] entetes = { "ID", "Nom", "Rue", "Ville", "Tel", "Mail" };

	public JTableEntreprise() {
		super();

		listEntr = (ArrayList<Entreprise>) entrDAO.getAll();

		this.setTitle("Entreprise");
		this.setSize(1000, 200);
		this.setLocationRelativeTo(null);

		ajouter = new JButton("Ajouter");
		supprimer = new JButton("Supprimer");
		panelBouton = new JPanel();
		panelBouton.add(ajouter);
		panelBouton.add(supprimer);

		tableModel = new JTableModel(listEntr, entetes);
		this.Jtableau = new JTable(tableModel);

		supprimer.addActionListener(new ActionListener() {

			@SuppressWarnings("null")
			public void actionPerformed(ActionEvent arg0) {

				if (Jtableau.getSelectedRow() != -1) {

					int option = JOptionPane.showConfirmDialog(null,
							"<html>Voulez-vous vraiment supprimer cette entreprise ?<br> </html>", "Confirmation",
							JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
					if (option == JOptionPane.OK_OPTION) {

						Entreprise entr = entrDAO.find((Integer) tableModel.getValueAt(Jtableau.getSelectedRow(), 0));
						tableModel.removeEntreprise(Jtableau.getSelectedRow());
						// on efface ses offres et ses stages

						ArrayList<Offre> liste = (ArrayList<Offre>) offrDAO.getAll_Entreprise(entr.getId());
						ArrayList<Stage> liste2 = null;
						for (Offre a : liste) {
							liste2.addAll((ArrayList<Stage>) stageDao.getAll_stage_by_offre(a.getId()));
							offrDAO.delete(a.getId());
						}
						for (Stage a : liste2) {
							stageDao.delete(a.getId());
						}
						// on efface sont adresse et son securite
						adreDAO.delete(entr.getIdAdresse());
						secuDAO.delete(entr.getIdSecurite());

						entrDAO.delete(entr.getId());

						JOptionPane.showMessageDialog(null, "Cette entreprise a �t� supprim�e de la base de donn�es",
								"Information", JOptionPane.INFORMATION_MESSAGE);
					}

				}
			}
		});

		ajouter.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {

				JDialog dialog = new JDialog();
				dialog.setTitle("Entreprise");
				dialog.setSize(800, 600);
				dialog.setLocationRelativeTo(null);
				CreerEntreprisePanel formulaire = new CreerEntreprisePanel(tableModel, dialog);
				dialog.getContentPane().add(formulaire);
				dialog.setVisible(true);

			}

		});

		this.getContentPane().add(new JScrollPane(Jtableau), layout.CENTER);
		this.getContentPane().add(panelBouton, layout.SOUTH);

		this.setVisible(true);
	}

}
