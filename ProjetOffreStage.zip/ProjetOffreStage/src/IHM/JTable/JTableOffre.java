package IHM.JTable;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import DAO.*;
import IHM.Creer.CreerOffreAdmin;
import Objet.*;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class JTableOffre extends JDialog {

	JTable Jtableau;

	OffreDAO offrDAO = new OffreDAO();
	StageDAO stageDao = new StageDAO();

	JPanel panelBouton;
	JButton ajouter;
	JButton supprimer;

	JTableModel tableModel;
	ArrayList<Offre> listEntr;
	BorderLayout layout = new BorderLayout();
	private final String[] entetes = { "ID", "Entreprise", "Titre", "Domaine", "Duree", "Contact", "Tel" };

	public JTableOffre() {
		super();

		listEntr = (ArrayList<Offre>) offrDAO.getAll();

		this.setTitle("Offre");
		this.setSize(1000, 200);
		this.setLocationRelativeTo(null);

		ajouter = new JButton("Ajouter");
		supprimer = new JButton("Supprimer");
		panelBouton = new JPanel();
		panelBouton.add(ajouter);
		panelBouton.add(supprimer);

		tableModel = new JTableModel(listEntr, entetes);
		this.Jtableau = new JTable(tableModel);

		supprimer.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {

				if (Jtableau.getSelectedRow() != -1) {

					int option = JOptionPane.showConfirmDialog(null,
							"<html>Voulez-vous vraiment supprimer cette offre ?<br> </html>", "Confirmation",
							JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
					if (option == JOptionPane.OK_OPTION) {
						ArrayList<Stage> liste = (ArrayList<Stage>) stageDao
								.getAll_stage_by_offre((Integer) tableModel.getValueAt(Jtableau.getSelectedRow(), 0));

						for (Stage a : liste) {
							stageDao.delete(a.getId());
						}

						offrDAO.delete((Integer) tableModel.getValueAt(Jtableau.getSelectedRow(), 0));
						tableModel.removeEntreprise(Jtableau.getSelectedRow());

						JOptionPane.showMessageDialog(null, "Cette offre a �t� supprim�e de la base de donn�es",
								"Information", JOptionPane.INFORMATION_MESSAGE);
					}

				}
			}
		});

		ajouter.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {

				JDialog dialog = new JDialog();
				dialog.setTitle("Offre");
				dialog.setSize(800, 575);
				dialog.setLocationRelativeTo(null);
				dialog.getContentPane().add(new CreerOffreAdmin(tableModel, dialog));
				dialog.setResizable(false);
				dialog.setVisible(true);
			}

		});

		this.getContentPane().add(new JScrollPane(Jtableau), layout.CENTER);
		this.getContentPane().add(panelBouton, layout.SOUTH);
		this.setVisible(true);
	}

}
