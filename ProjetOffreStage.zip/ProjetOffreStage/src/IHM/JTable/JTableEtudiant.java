package IHM.JTable;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import DAO.*;
import IHM.Creer.CreerEtudiantPanel;
import Objet.*;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class JTableEtudiant extends JDialog {

	JTable Jtableau;

	EtudiantDAO etudDAO = new EtudiantDAO();
	SecuriteDAO secuDAO = new SecuriteDAO();
	AdresseDAO adreDAO = new AdresseDAO();
	StageDAO stageDao = new StageDAO();

	JPanel panelBouton;
	JButton ajouter;
	JButton supprimer;

	JTableModel tableModel;
	ArrayList<Etudiant> listEntr;
	BorderLayout layout = new BorderLayout();

	public JTableEtudiant() {

		super();

		listEntr = (ArrayList<Etudiant>) etudDAO.getAll();

		this.setTitle("Etudiant");
		this.setSize(1000, 200);
		this.setLocationRelativeTo(null);

		ajouter = new JButton("Ajouter");
		supprimer = new JButton("Supprimer");
		panelBouton = new JPanel();
		panelBouton.add(ajouter);
		panelBouton.add(supprimer);

		String[] title = { "Id", "Nom", "Prenom", "Rue", "Ville", "Email" };
		tableModel = new JTableModel(listEntr, title);
		this.Jtableau = new JTable(tableModel);

		supprimer.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {

				if (Jtableau.getSelectedRow() != -1) {

					int option = JOptionPane.showConfirmDialog(null,
							"<html>Voulez-vous vraiment supprimer cet etudiant ?<br> </html>", "Confirmation",
							JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
					if (option == JOptionPane.OK_OPTION) {
						Etudiant etudiant = etudDAO.find((Integer) tableModel.getValueAt(Jtableau.getSelectedRow(), 0));
						tableModel.removeEntreprise(Jtableau.getSelectedRow());
						secuDAO.delete(etudiant.getIdSecurite());
						adreDAO.delete(etudiant.getIdAdresse());

						ArrayList<Stage> liste = (ArrayList<Stage>) stageDao.getAll_stage_by_etudiant(etudiant.getId());
						for (Stage a : liste) {
							stageDao.delete(a.getId());
						}

						etudDAO.delete(etudiant.getId());
						JOptionPane.showMessageDialog(null, "Cet etudiant a �t� supprim�e de la base de donn�es",
								"Information", JOptionPane.INFORMATION_MESSAGE);
					}

				}
			}
		});

		ajouter.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {

				JDialog dialog = new JDialog();
				dialog.setTitle("Etudiant");
				dialog.setSize(800, 600);
				dialog.setLocationRelativeTo(null);
				dialog.getContentPane().add(new CreerEtudiantPanel(dialog));
				dialog.setVisible(true);
			}

		});

		this.getContentPane().add(new JScrollPane(Jtableau), layout.CENTER);
		this.getContentPane().add(panelBouton, layout.SOUTH);
		this.setVisible(true);
	}

}
