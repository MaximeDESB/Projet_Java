package IHM.JTable;

import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;

import DAO.AdresseDAO;
import DAO.DomaineDAO;
import DAO.EntrepriseDAO;
import Objet.Entreprise;
import Objet.Etudiant;
import Objet.Offre;

/* Regroupe les points communs entre les JTables */ 
public class JTableModel extends AbstractTableModel {

	private ArrayList list = new ArrayList();

	private EntrepriseDAO entrDAO;
	private AdresseDAO adreDAO;
	DomaineDAO domaDAO;
	private String[] entetes;

	public JTableModel(ArrayList liste, String[] nomColonnes) {
		super();

		entetes = nomColonnes;
		this.list = liste;
		adreDAO = new AdresseDAO();
		domaDAO = new DomaineDAO();
		entrDAO = new EntrepriseDAO();
	}

	public int getRowCount() {
		return list.size();
	}

	public int getColumnCount() {
		return entetes.length;
	}

	public String getColumnName(int columnIndex) {
		return entetes[columnIndex];
	}

	public void addOffre(Offre entr) {
		list.add(entr);
		fireTableRowsInserted(list.size() - 1, list.size() - 1);
	}

	public void removeOffre(int ligne) {
		list.remove(ligne);

		fireTableRowsDeleted(ligne, ligne);
	}

	public void addEtudiant(Etudiant entr) {
		list.add(entr);
		fireTableRowsInserted(list.size() - 1, list.size() - 1);
	}

	public void removeEtudiant(int ligne) {
		list.remove(ligne);

		fireTableRowsDeleted(ligne, ligne);
	}

	public void addEntreprise(Entreprise entr) {
		list.add(entr);
		fireTableRowsInserted(list.size() - 1, list.size() - 1);
	}

	public void removeEntreprise(int ligne) {
		list.remove(ligne);

		fireTableRowsDeleted(ligne, ligne);
	}

	public Object getValueAt(int rowIndex, int columnIndex) {

		if (list.get(0) instanceof Entreprise) {
			switch (columnIndex) {
			case 0:
				return ((Entreprise) list.get(rowIndex)).getId();
			case 1:
				return ((Entreprise) list.get(rowIndex)).getNom();
			case 2:
				return (adreDAO.find((Integer) ((Entreprise) list.get(rowIndex)).getIdAdresse())).getRue();
			case 3:
				return adreDAO.find((Integer) ((Entreprise) list.get(rowIndex)).getIdAdresse()).getVille();
			case 4:
				return ((Entreprise) list.get(rowIndex)).getTel();
			case 5:
				return ((Entreprise) list.get(rowIndex)).getEmail();
			default:
				return null;
			}
		}

		if (list.get(0) instanceof Etudiant) {

			switch (columnIndex) {
			case 0:
				return ((Etudiant) list.get(rowIndex)).getId();
			case 1:
				return ((Etudiant) list.get(rowIndex)).getNom();
			case 2:
				return ((Etudiant) list.get(rowIndex)).getPrenom();
			case 3:
				return (adreDAO.find(((Etudiant) list.get(rowIndex)).getIdAdresse())).getRue();
			case 4:
				return adreDAO.find(((Etudiant) list.get(rowIndex)).getIdAdresse()).getVille();
			case 5:
				return ((Etudiant) list.get(rowIndex)).getEmail();

			default:
				return null;
			}
		}

		if (list.get(0) instanceof Offre) {
			switch (columnIndex) {
			case 0:
				return ((Offre) list.get(rowIndex)).getId();
			case 1:
				return entrDAO.find(((Offre) list.get(rowIndex)).getIdEntreprise()).getNom();
			case 2:
				return ((Offre) list.get(rowIndex)).getNomOffre();
			case 3:
				return domaDAO.find((Integer) ((Offre) list.get(rowIndex)).getIdDomaine()).getNom();
			case 4:
				return ((Offre) list.get(rowIndex)).getDuree();
			case 5:
				return entrDAO.find(((Offre) list.get(rowIndex)).getIdEntreprise()).getEmail();

			case 6:
				return entrDAO.find(((Offre) list.get(rowIndex)).getIdEntreprise()).getTel();
			default:
				return null;
			}
		}

		return null;
	}

}