package IHM;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import Objet.Offre;

/* L'etudiant ecrit sa lettre de motivation sur ce panel */

public class Motivation_JDialog extends JDialog {

	JPanel main;
	JPanel panelBouton;
	JPanel titre;
	JPanel zone_motiv;
	BorderLayout border;
	JButton envoyer;
	JButton annuler;
	public Font police = new Font(" TimesRoman", Font.ITALIC, 30);
	public JTextArea description = new JTextArea(60, 40);
	Motivation_JDialog me;
	Offre ofr;
	JLabel label = new JLabel("Parlez nous un peu de vous : ");

	public Motivation_JDialog(Offre o) {
		super();

		this.setTitle("Vos motivations");
		this.setSize(600, 400);
		this.setLocationRelativeTo(null);

		me = this;
		ofr = o;
		main = new JPanel();
		panelBouton = new JPanel();
		titre = new JPanel();
		zone_motiv = new JPanel();
		border = new BorderLayout();
		envoyer = new JButton("Postuler");
		annuler = new JButton("Quitter");

		this.getContentPane().add(titre, border.NORTH);
		this.getContentPane().add(main, border.CENTER);
		this.getContentPane().add(panelBouton, border.SOUTH);

		main.add(zone_motiv);
		label.setFont(police);
		titre.add(label);
		titre.setFont(police);
		zone_motiv.add(description);
		description.setEditable(true);
		panelBouton.add(envoyer);
		panelBouton.add(annuler);

		envoyer.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {

				if (Fenetre.getEtudiantLog().postuler(ofr, description.getText())) {
					JOptionPane.showMessageDialog(null, "Votre candidature a bien �t� pris en compte", "Information",
							JOptionPane.INFORMATION_MESSAGE);
					Fenetre.cardLayout.show(Fenetre.mainPanel, "Acceuil_log");
					me.setVisible(false);
				} else {
					JOptionPane.showMessageDialog(null, "Vous avez deja postuler pour cette offre", "Information",
							JOptionPane.INFORMATION_MESSAGE);
				}

			}
		});

		annuler.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {

				me.setVisible(false);
			}

		});
		this.setVisible(true);
	}

}
