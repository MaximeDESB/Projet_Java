package IHM;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

import Objet.Entreprise;
import Objet.Etudiant;

public class Fenetre extends JFrame {

	public static JPanel mainPanel = new JPanel(); // Panel principal


	public static CardLayout cardLayout = new CardLayout();
	public JPanel boutonPane = new JPanel();

	public static JScrollPane levelScroll;
	public static JPanel level_0;
	public static JPanel level_1;
	public static JPanel level_2;
	public static JPanel level_3;
	public static JPanel level_4;

	public static JFrame getFrame;

	private static Etudiant etudiantLog;
	private static Entreprise entrepriseLog;

	public static Color couleurBlanc = new Color(255, 255, 255);
	public static Color couleurGrise = new Color(220, 220, 220);

	public static void setEtudiantLog(Etudiant etudiantlog) {
		Fenetre.etudiantLog = etudiantlog;
	}

	public Fenetre() {

		this.setTitle("Gestion de stage");
		this.setSize(800, 600);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		this.getFrame = this;

		/* Le mainPanel est le panel d'affichage principal, il contient les differents niveau 
		 * du programme (level 1 , 2 ,3 4) */

		mainPanel.setLayout(cardLayout);

		this.add(mainPanel);

		Font policeCalibri = new Font(" Calibri ", Font.LAYOUT_RIGHT_TO_LEFT, 15);




		this.getContentPane().add(boutonPane, BorderLayout.NORTH);
		this.getContentPane().add(mainPanel, BorderLayout.CENTER);

		this.setVisible(true);

	}

	public static Etudiant getEtudiantLog() {
		return etudiantLog;
	}

	public static Entreprise getEntrepriseLog() {
		return entrepriseLog;
	}

	public static void setEntrepriseLog(Entreprise entrepriseLog) {
		Fenetre.entrepriseLog = entrepriseLog;

	}
}
