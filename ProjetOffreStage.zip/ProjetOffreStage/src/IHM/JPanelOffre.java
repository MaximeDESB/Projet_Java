package IHM;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import Autre.ChangerDate;
import DAO.DomaineDAO;
import DAO.EntrepriseDAO;
import Objet.Offre;

/* Ce panel affiche une offre */
public class JPanelOffre extends JPanel {

	JPanel Jnom;
	JPanel Jdomaine;
	JPanel Jduree;
	JPanel Jdate;
	JPanel JnomEntr;
	JPanel Droite;
	JPanel Haut;
	JPanel Centre;
	JPanel Bas;
	public JPanel Gauche;
	protected JPanel panelBouton;
	JPanel Centre1;
	protected JPanel Jentreprise;
	JPanel vide;
	protected JPanelAvecImagedeFond fond;

	JLabel nom;
	JLabel domaine;
	JLabel duree;
	JLabel date;
	JLabel nomEntr;
	JLabel description;
	public JLabel entreprise;
	public JLabel LabelAffiche;
	public JTextArea description2;

	Offre offre;
	JButton retour;
	public JButton postuler;

	JScrollPane scroll;

	Font policeTimesRoman = new Font(" TimesRoman ", Font.BOLD, 15);
	BorderLayout layout = new BorderLayout();
	GridLayout grid = new GridLayout(6, 1, 15, 15);

	DomaineDAO domaineDAO;
	protected EntrepriseDAO entrDAO;

	public Image ImageAffiche;
	public String nomImage;

	public JPanelOffre(final Offre offre) {
		super();
		this.offre = offre;
		domaineDAO = new DomaineDAO();
		entrDAO = new EntrepriseDAO();

		Droite = new JPanel();
		Jnom = new JPanel();
		Jdomaine = new JPanel();
		Jduree = new JPanel();
		Jdate = new JPanel();
		JnomEntr = new JPanel();
		Haut = new JPanel();
		Centre = new JPanel();
		Gauche = new JPanel();
		Bas = new JPanel();
		panelBouton = new JPanelAvecImagedeFond("images\\fond2.jpg");
		Centre1 = new JPanel();
		Jentreprise = new JPanel();
		vide = new JPanel();

		Droite.setOpaque(false);
		Jnom.setOpaque(false);
		Jdomaine.setOpaque(false);
		Jduree.setOpaque(false);
		Jdate.setOpaque(false);
		JnomEntr.setOpaque(false);
		Haut.setOpaque(false);
		Centre.setOpaque(false);
		Gauche.setOpaque(false);
		Bas.setOpaque(false);
		Centre1.setOpaque(false);
		Jentreprise.setOpaque(false);
		vide.setOpaque(false);

		fond = new JPanelAvecImagedeFond("images\\fond2.jpg");
		fond.setPreferredSize(new Dimension(795, 535));
		this.add(fond);
		fond.setLayout(layout);
		Droite.setLayout(grid);
		Centre.setLayout(new GridLayout(2, 1));
		Centre1.setLayout(new GridLayout(1, 2));
		Gauche.setLayout(new GridLayout(2, 1));

		retour = new JButton("Retour");
		postuler = new JButton("Postuler");

		nom = new JLabel("" + offre.getNomOffre());
		nom.setFont(policeTimesRoman);
		Jnom.add(nom);
		Haut.add(Jnom);

		Droite.add(vide);
		domaine = new JLabel("Domaine   : " + domaineDAO.find(offre.getIdDomaine()).getNom());
		domaine.setFont(policeTimesRoman);
		Jdomaine.add(domaine);
		Droite.add(Jdomaine);

		duree = new JLabel("Dur�e   : " + offre.getDuree() + " Jour(s)");
		duree.setFont(policeTimesRoman);
		Jduree.add(duree);
		Droite.add(Jduree);

		String numero = ChangerDate.toString(offre.getDateDebut());
		date = new JLabel("Date de Debut   : " + numero);
		date.setFont(policeTimesRoman);
		Jdate.add(date);
		Droite.add(Jdate);

		description = new JLabel("Description   : ");
		description2 = new JTextArea();
		description2.setText(offre.getDescription());
		description2.setEditable(false);
		description.setFont(policeTimesRoman);

		scroll = new JScrollPane(description2);
		scroll.setPreferredSize(new Dimension(450, 50));

		// met le scroll en Haut
		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				scroll.getVerticalScrollBar().setValue(0);
			}
		});

		nomImage = entrDAO.find(offre.getIdEntreprise()).getLogo();
		ImageIcon ImageAfficheFilm = new ImageIcon(nomImage);
		ImageAffiche = scaleImage(ImageAfficheFilm.getImage(), 160);
		LabelAffiche = new JLabel(new ImageIcon(ImageAffiche));
		Gauche.add(LabelAffiche);

		entreprise = new JLabel("Entreprise  : " + entrDAO.find(offre.getIdEntreprise()).getNom());
		entreprise.setFont(policeTimesRoman);
		Jentreprise.add(entreprise);
		Gauche.add(Jentreprise);

		panelBouton.add(postuler);
		panelBouton.add(retour);
		fond.add(Haut, BorderLayout.NORTH);
		fond.add(Centre, BorderLayout.CENTER);
		fond.add(panelBouton, BorderLayout.SOUTH);
		Centre1.add(Gauche);
		Centre1.add(Droite);
		Centre.add(Centre1);
		Centre.add(scroll);

		nom.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		postuler.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {

				new Motivation_JDialog(offre);
			}

		});

		retour.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {

				Fenetre.cardLayout.show(Fenetre.mainPanel, "level_scroll");

			}

		});
	}

	// adaptation image
	public static Image scaleImage(Image source, int width, int height) {
		BufferedImage img = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
		Graphics2D g = (Graphics2D) img.getGraphics();
		g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
		g.drawImage(source, 0, 0, width, height, null);
		g.dispose();
		return img;
	}

	public static Image scaleImage(Image source, int size) {
		int width = source.getWidth(null);
		int height = source.getHeight(null);
		double f = 0;
		if (width < height) {// portrait
			f = (double) height / (double) width;
			width = (int) (size / f);
			height = size;
		} else {// paysage
			f = (double) width / (double) height;
			width = size;
			height = (int) (size / f);
		}
		return scaleImage(source, width, height);
	}

}
