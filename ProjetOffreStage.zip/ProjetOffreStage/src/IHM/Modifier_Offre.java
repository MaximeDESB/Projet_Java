package IHM;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import Autre.ChangerDate;
import DAO.DomaineDAO;
import DAO.OffreDAO;
import Objet.Domaine;
import Objet.Offre;

public class Modifier_Offre extends JPanelOffre {

	public JTextField texfieldNom;
	public JTextField texfieldDuree;
	protected JTextField texfieldDate;

	JLabel duree2;

	JComboBox<String> comboDomaine = new JComboBox<String>();
	public DomaineDAO domaDAO = new DomaineDAO();
	public String domaineChoose;

	public DateFormat formater;
	JButton modifier;

	public OffreDAO offreDao;
	public boolean flag;

	public Modifier_Offre(final Offre offre) {
		super(offre);

		texfieldNom = new JTextField(offre.getNomOffre());
		texfieldDuree = new JTextField("" + offre.getDuree());

		// nom
		texfieldNom.setPreferredSize(new Dimension(300, 30));
		Jnom.remove(nom);
		Jnom.add(texfieldNom);
		texfieldNom.setFont(policeTimesRoman);

		// dur�e
		duree2 = new JLabel("  Jour(s) ");
		texfieldDuree.setFont(policeTimesRoman);
		duree2.setFont(policeTimesRoman);
		texfieldDuree.setPreferredSize(new Dimension(100, 20));
		duree.setText("Dur�e   : ");
		Jduree.add(duree);
		Jduree.add(texfieldDuree);
		Jduree.add(duree2);

		// domaine
		ArrayList<Domaine> listDomaine = (ArrayList<Domaine>) domaDAO.getAll();

		for (Domaine d : listDomaine) {
			comboDomaine.addItem(d.getNom());
		}
		comboDomaine.setPreferredSize(new Dimension(150, 20));
		domaine.setText("Domaine   : ");
		Jdomaine.add(comboDomaine);
		comboDomaine.setSelectedIndex(offre.getIdDomaine() - 1);

		// j'initialise domainechoose au cas ou il n'y as pas de changement de
		// domaine
		domaineChoose = domaDAO.find(offre.getIdDomaine()).getNom();

		comboDomaine.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				domaineChoose = (String) e.getItem();
			}
		});

		// date
		formater = new SimpleDateFormat("dd/MM/yyyy");
		texfieldDate = new JTextField(ChangerDate.toStringModifier(offre.getDateDebut()));
		date.setText("Date de Debut  : ");
		Jdate.add(date);
		Jdate.add(texfieldDate);
		texfieldDate.setFont(policeTimesRoman);
		texfieldDate.setPreferredSize(new Dimension(100, 20));

		// description
		description2.setEditable(true);

		// bouton
		modifier = new JButton();
		modifier.setText("Modifier");
		modifier.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				flag = true;
				offre.setIdDomaine(domaDAO.find_id(domaineChoose));
				offre.setNomOffre(texfieldNom.getText());
				offre.setDescription(description2.getText());

				if (texfieldDuree.getText().equals("0")) {
					flag = false;
					JOptionPane.showMessageDialog(null, "La dur�e ne peut pas �tre de 0 jour", "Information",
							JOptionPane.ERROR_MESSAGE);
				}

				try {
					offre.setDuree(Integer.parseInt(texfieldDuree.getText()));
				} catch (NumberFormatException e1) {
					flag = false;
					JOptionPane.showMessageDialog(null, "Erreur dans la dur�e de l'offre", "Information",
							JOptionPane.ERROR_MESSAGE);
				}
				// date
				Date dateUtil = null;
				try {
					dateUtil = formater.parse(texfieldDate.getText());
					Date dateSql = new java.sql.Date(dateUtil.getTime());
					offre.setDateDebut((java.sql.Date) dateSql);
				} catch (ParseException e1) {
					JOptionPane.showMessageDialog(null, "Erreur dans la Date de l'offre\n(JJ/MM/AAAA)", "Information",
							JOptionPane.ERROR_MESSAGE);
					flag = false;
				}

				offreDao = new OffreDAO();

				if (flag) {
					offreDao.update(offre);
					JOptionPane.showMessageDialog(null, "Votre offre a bien �t� modifi�e!", "Information",
							JOptionPane.INFORMATION_MESSAGE);
				}

			}

		});

		retour.removeActionListener(retour.getActionListeners()[0]);
		retour.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {
				Fenetre.cardLayout.show(Fenetre.mainPanel, "level_2");

			}
		});

		panelBouton.removeAll();
		panelBouton.add(modifier);
		panelBouton.add(retour);
		fond.add(panelBouton, BorderLayout.SOUTH);

	}

}
