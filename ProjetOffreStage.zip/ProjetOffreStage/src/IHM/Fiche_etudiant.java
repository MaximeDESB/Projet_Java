package IHM;

import java.awt.BorderLayout;
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;

import DAO.EtudiantDAO;
import DAO.OffreDAO;
import DAO.StageDAO;
import Objet.Etudiant;
import Objet.Offre;
import Objet.Stage;

/* Voir la candidature d'un candidat en details : cv et lettre de motivation */

public class Fiche_etudiant extends JPanel {

	StageDAO stagDAO = new StageDAO();
	OffreDAO offrDAO = new OffreDAO();
	EtudiantDAO etudDAO = new EtudiantDAO();
	Stage stage;
	Offre offre;
	Etudiant etudiant;
	BorderLayout border;
	JTextArea motivation = new JTextArea(30, 40);

	JLabel label_motivation = new JLabel("Ce qu'il vous a ecrit : ");
	JPanel boutonPanel = new JPanel();
	JPanel centerPanel = new JPanel();

	JButton cv = new JButton();
	JButton accepter = new JButton("Accepter");
	JButton refuser = new JButton("Refuser");
	JButton attendre = new JButton("Attendre");
	public Font police = new Font(" TimesRoman", Font.ITALIC, 20);
	JPanelAvecImagedeFond fond = new JPanelAvecImagedeFond("images\\fond2.jpg", 800, 600);

	public Fiche_etudiant(Stage s) {

		stage = s;
		offre = offrDAO.find(s.getIdOffre());
		etudiant = etudDAO.find(s.getIdEtudiant());

		Choix_candidat_Entreprise banniere = new Choix_candidat_Entreprise(s);

		this.add(fond);
		fond.setPreferredSize(new Dimension(794, 536));
		border = new BorderLayout();
		BorderLayout border2 = new BorderLayout();
		fond.setLayout(border);
		fond.add(banniere, border.NORTH);

		centerPanel.setLayout(border2);

		centerPanel.add(label_motivation, border2.NORTH);
		centerPanel.add(motivation, border2.CENTER);
		label_motivation.setHorizontalAlignment(SwingConstants.CENTER);
		label_motivation.setFont(police);
		fond.add(centerPanel, border.CENTER);
		motivation.setText(stage.getMotivation());
		motivation.setEditable(false);
		centerPanel.setOpaque(false);

		cv.setIcon(new ImageIcon("images//cv.png"));
		cv.setText("Voir le CV");
		accepter.setIcon(new ImageIcon("images//accepter.png"));
		refuser.setIcon(new ImageIcon("images//refuser.png"));
		attendre.setIcon(new ImageIcon("images//attendre.png"));

		banniere.panelBouton.remove(banniere.selectionner);
		banniere.panelBouton.add(cv);

		cv.setVerticalTextPosition(SwingConstants.TOP);
		cv.setHorizontalTextPosition(SwingConstants.CENTER);

		accepter.setVerticalTextPosition(SwingConstants.TOP);
		accepter.setHorizontalTextPosition(SwingConstants.CENTER);

		refuser.setVerticalTextPosition(SwingConstants.TOP);
		refuser.setHorizontalTextPosition(SwingConstants.CENTER);

		refuser.setVerticalTextPosition(SwingConstants.TOP);
		refuser.setHorizontalTextPosition(SwingConstants.CENTER);

		attendre.setVerticalTextPosition(SwingConstants.TOP);
		attendre.setHorizontalTextPosition(SwingConstants.CENTER);

		boutonPanel.add(accepter);
		boutonPanel.add(refuser);
		boutonPanel.add(attendre);
		boutonPanel.setOpaque(false);

		fond.add(boutonPanel, border.SOUTH);

		refuser.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {

				stage.setStatut("Refuse");
				stagDAO.update(stage);
				Fenetre.cardLayout.show(Fenetre.mainPanel, "level_2");
			}

		});

		attendre.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {
				stage.setStatut("En attente");
				stagDAO.update(stage);;
				Fenetre.cardLayout.show(Fenetre.mainPanel, "level_2");

			}

		});

		accepter.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {
				stage.setStatut("Retenu");
				stagDAO.update(stage);
				etudiant.setNouveauStage(true);
				etudDAO.update(etudiant);
				Fenetre.cardLayout.show(Fenetre.mainPanel, "level_2");
			}

		});

		cv.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {
				try {
					Etudiant postulant = etudDAO.find(stage.getIdEtudiant());
					Desktop.getDesktop().open(new File(postulant.getPathCv()));

				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		});
	}

}
