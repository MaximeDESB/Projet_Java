package IHM.Creer;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

import DAO.OffreDAO;
import IHM.JTable.JTableModel;
import Objet.Entreprise;
import Objet.Offre;

public class CreerOffreAdmin extends CreerOffreEntreprise {

	static Offre offre = new Offre(1);
	JComboBox<String> comboEntreprise = new JComboBox<String>();
	CreerOffreAdmin me;
	public String entrepriseChoose;

	JButton enregistrer2 = new JButton("Enregistrer");
	JButton quitter = new JButton("Quitter");

	public CreerOffreAdmin(final JTableModel jmodel, final JDialog dialog) {
		super(offre);
		me = this;
		ArrayList<Entreprise> listEntreprise = (ArrayList<Entreprise>) entrDAO.getAll();

		for (Entreprise d : listEntreprise) {
			comboEntreprise.addItem(d.getNom());
		}
		comboEntreprise.setPreferredSize(new Dimension(150, 20));
		entreprise.setText("Entreprise   : ");
		Jentreprise.add(comboEntreprise);
		comboEntreprise.setSelectedIndex(-1);

		comboEntreprise.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {

				entrepriseChoose = (String) e.getItem();
				Gauche.removeAll();

				nomImage = entrDAO.find_nom(entrepriseChoose).getLogo();
				ImageIcon ImageAfficheFilm = new ImageIcon(nomImage);
				ImageAffiche = scaleImage(ImageAfficheFilm.getImage(), 160);
				LabelAffiche = new JLabel(new ImageIcon(ImageAffiche));

				Gauche.add(LabelAffiche);
				Gauche.add(Jentreprise);
				SwingUtilities.updateComponentTreeUI(me);
			}
		});

		LabelAffiche.removeAll();
		nomImage = "images//Default.png";
		ImageIcon ImageAfficheFilm = new ImageIcon(nomImage);
		ImageAffiche = scaleImage(ImageAfficheFilm.getImage(), 160);
		LabelAffiche = new JLabel(new ImageIcon(ImageAffiche));

		Gauche.removeAll();
		Gauche.add(LabelAffiche);
		Gauche.add(Jentreprise);

		enregistrer2.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				flag = true;
				offre.setIdDomaine(domaDAO.find_id(domaineChoose));
				offre.setIdEntreprise(entrDAO.find_nom(entrepriseChoose).getId());

				offre.setNomOffre(texfieldNom.getText());
				offre.setDescription(description2.getText());

				if (texfieldDuree.getText().equals("0")) {
					flag = false;
					JOptionPane.showMessageDialog(null, "La dur�e ne peut pas �tre de 0 jour", "Information",
							JOptionPane.ERROR_MESSAGE);
				}

				if (entrepriseChoose == null) {
					flag = false;
					JOptionPane.showMessageDialog(null, "Veuillez choisir une Entreprise", "Information",
							JOptionPane.ERROR_MESSAGE);
				}

				if (domaineChoose == null) {
					flag = false;
					JOptionPane.showMessageDialog(null, "Veuillez choisir un Domaine", "Information",
							JOptionPane.ERROR_MESSAGE);
				}

				try {
					offre.setDuree(Integer.parseInt(texfieldDuree.getText()));
				} catch (NumberFormatException e1) {
					flag = false;
					JOptionPane.showMessageDialog(null, "Erreur dans la dur�e de l'offre", "Information",
							JOptionPane.ERROR_MESSAGE);
				}
				// date
				Date dateUtil = null;
				try {
					dateUtil = formater.parse(texfieldDate.getText());
					Date dateSql = new java.sql.Date(dateUtil.getTime());
					offre.setDateDebut((java.sql.Date) dateSql);
				} catch (ParseException e1) {
					JOptionPane.showMessageDialog(null, "Erreur dans la Date de l'offre\n(JJ/MM/AAAA)", "Information",
							JOptionPane.ERROR_MESSAGE);
					flag = false;
				}

				offreDao = new OffreDAO();

				if (flag) {
					offreDao.create(offre);
					jmodel.addOffre(offre);
					JOptionPane.showMessageDialog(null, "Votre offre a bien �t� cr�er!", "Information",
							JOptionPane.INFORMATION_MESSAGE);
				}

			}

		});

		quitter.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				dialog.setVisible(false);

			}
		});

		panelBouton.removeAll();
		panelBouton.add(enregistrer2);
		panelBouton.add(quitter);
		fond.add(panelBouton, BorderLayout.SOUTH);

	}

}
