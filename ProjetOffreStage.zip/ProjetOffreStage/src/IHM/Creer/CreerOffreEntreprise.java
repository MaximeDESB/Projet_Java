package IHM.Creer;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.ParseException;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import Objet.*;
import DAO.*;
import IHM.Fenetre;
import IHM.Modifier_Offre;

import java.util.Date;

public class CreerOffreEntreprise extends Modifier_Offre {

	JButton enregistrer;
	JButton retour2;

	public CreerOffreEntreprise(final Offre offre) {
		super(offre);
		texfieldDate.setText("jj/mm/aaaa");

		retour2 = new JButton("Retour");
		retour2.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {
				Fenetre.cardLayout.show(Fenetre.mainPanel, "level_1");
			}
		});
		
		enregistrer = new JButton();
		enregistrer.setText("Enregistrer");
		enregistrer.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				flag = true;
				offre.setIdDomaine(domaDAO.find_id(domaineChoose));
				offre.setNomOffre(texfieldNom.getText());
				offre.setDescription(description2.getText());

				if (texfieldDuree.getText().equals("0")) {
					flag = false;
					JOptionPane.showMessageDialog(null, "La dur�e ne peut pas �tre de 0 jour", "Information",
							JOptionPane.ERROR_MESSAGE);
				}

				if (domaineChoose == null) {
					flag = false;
					JOptionPane.showMessageDialog(null, "Veuillez choisir un Domaine", "Information",
							JOptionPane.ERROR_MESSAGE);
				}

				try {
					offre.setDuree(Integer.parseInt(texfieldDuree.getText()));
				} catch (NumberFormatException e1) {
					flag = false;
					JOptionPane.showMessageDialog(null, "Erreur dans la dur�e de l'offre", "Information",
							JOptionPane.ERROR_MESSAGE);
				}
				// date
				Date dateUtil = null;
				try {
					dateUtil = formater.parse(texfieldDate.getText());
					Date dateSql = new java.sql.Date(dateUtil.getTime());
					offre.setDateDebut((java.sql.Date) dateSql);
				} catch (ParseException e1) {
					JOptionPane.showMessageDialog(null, "Erreur dans la Date de l'offre\n(JJ/MM/AAAA)", "Information",
							JOptionPane.ERROR_MESSAGE);
					flag = false;
				}

				offreDao = new OffreDAO();

				if (flag) {
					offreDao.create(offre);
					JOptionPane.showMessageDialog(null, "Votre offre a bien �t� modifi�e!", "Information",
							JOptionPane.INFORMATION_MESSAGE);
				}

			}

		});

		panelBouton.removeAll();
		panelBouton.add(enregistrer);
		panelBouton.add(retour2);
		fond.add(panelBouton, BorderLayout.SOUTH);
	}

}
