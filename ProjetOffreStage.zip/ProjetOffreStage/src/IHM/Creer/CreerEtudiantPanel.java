package IHM.Creer;

import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

import Action.ActionButtonQuitter;
import Autre.Md5;
import DAO.AdresseDAO;
import DAO.EtudiantDAO;
import DAO.SecuriteDAO;
import Objet.Adresse;
import Objet.Etudiant;
import Objet.Securite;

public class CreerEtudiantPanel extends JPanel {

	Font policeTimesRoman = new Font(" TimesRoman ", Font.BOLD, 15);
	JPanel Jtitre;
	JPanel Jnom;
	JPanel Jprenom;
	JPanel Jadresse;
	JPanel Jville;
	JPanel Jmail;
	JPanel Jlogin;
	JPanel Jmdp;
	JPanel Jbutton;

	JLabel Titre = new JLabel("Creation d'un �tudiant");
	JLabel Nom = new JLabel("Nom 	: ");
	JLabel Prenom = new JLabel("Prenom 	: ");
	JLabel Adresse = new JLabel("Adresse (numero et rue)	 : ");
	JLabel Ville = new JLabel("Ville	 : ");
	JLabel Mail = new JLabel("Mail (contact)	 : ");
	JLabel Pseudo = new JLabel("Pseudo	 : ");
	JLabel Mdp = new JLabel("Mot de passe	 : ");

	JTextField texfieldNom = new JTextField(20);
	JTextField texfieldPrenom = new JTextField(20);
	JTextField texfieldAdresse = new JTextField(20);
	JTextField texfieldVille = new JTextField(20);
	JTextField texfieldLogin = new JTextField(20);
	JTextField texfieldMdp = new JTextField(20);
	JTextField texfieldMail = new JTextField(20);

	JButton enregistrer = new JButton("Enregistrer");
	JButton quitter = new JButton("Quitter");
	Md5 md5 = new Md5();

	public CreerEtudiantPanel(final JDialog dialog) {
		super();

		this.setLayout(new GridLayout(9, 1));

		Jtitre = new JPanel();
		Jnom = new JPanel();
		Jprenom = new JPanel();
		Jadresse = new JPanel();
		Jville = new JPanel();
		Jmail = new JPanel();
		Jlogin = new JPanel();
		Jmdp = new JPanel();
		Jbutton = new JPanel();

		this.Jtitre.add(Titre);
		Titre.setFont(policeTimesRoman);
		this.add(Jtitre);

		this.Jnom.add(Nom);
		Nom.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		Nom.setFont(policeTimesRoman);
		this.Jnom.add(texfieldNom);
	
		this.add(Jnom);

		this.Jprenom.add(Prenom);
		Prenom.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		Prenom.setFont(policeTimesRoman);
		this.Jprenom.add(texfieldPrenom);
		this.add(Jprenom);

		this.Jadresse.add(Adresse);
		Adresse.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		Adresse.setFont(policeTimesRoman);
		this.Jadresse.add(texfieldAdresse);
		this.add(Jadresse);

		this.Jville.add(Ville);
		Ville.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		Ville.setFont(policeTimesRoman);
		this.Jville.add(texfieldVille);
		this.add(Jville);

		this.Jmail.add(Mail);
		Mail.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		Mail.setFont(policeTimesRoman);
		this.Jmail.add(texfieldMail);
		this.add(Jmail);

		this.Jlogin.add(Pseudo);
		Pseudo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		Pseudo.setFont(policeTimesRoman);
		this.Jlogin.add(texfieldLogin);
		this.add(Jlogin);

		this.Jmdp.add(Mdp);
		Mdp.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		Mdp.setFont(policeTimesRoman);
		this.Jmdp.add(texfieldMdp);
		this.add(Jmdp);

		Jbutton.add(enregistrer);
		Jbutton.add(quitter);
		this.add(Jbutton);

		quitter.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent arg0) {

				dialog.setVisible(false);
			}

		});

		enregistrer.addActionListener(new AbstractAction() {

			public void actionPerformed(ActionEvent arg0) {

				Etudiant etudiant;
				Adresse adr;
				Securite secu;

				AdresseDAO adrDAO = new AdresseDAO();
				EtudiantDAO entrDAO = new EtudiantDAO();
				SecuriteDAO secuDAO = new SecuriteDAO();
				// encode le mdp

				md5.pass(texfieldMdp.getText());
				adr = new Adresse(texfieldAdresse.getText(), texfieldVille.getText());
				secu = new Securite(texfieldLogin.getText(), md5.getCode());

				adrDAO.create(adr);
				secuDAO.create(secu);

				etudiant = new Etudiant(texfieldNom.getText(), texfieldPrenom.getText(), texfieldMail.getText(),
						adr.getId(), secu.getId());
				entrDAO.create(etudiant);

				JOptionPane.showMessageDialog(null, "L'Etudiant a bien �t� enregistr�!", "Information",
						JOptionPane.INFORMATION_MESSAGE);

			}

		});
	}

}
