package IHM;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;

import Objet.*;
import DAO.*;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

// Il s'agit d'un panel permettant de choisir un film

public class ChoixStageJPanel extends JPanel {

	public Image ImageAffiche;
	public String nomImage;

	protected JPanel infoStage = new JPanel();
	protected JPanel panelBouton = new JPanel();

	public BorderLayout layout = new BorderLayout();
	public Font police = new Font(" TimesRoman", Font.BOLD, 20);

	public JLabel titre = new JLabel();
	public JLabel boite = new JLabel();
	public JLabel Ldomaine = new JLabel();

	ChoixStageJPanel myself = this;
	public JButton selectionner = new JButton("Selectionner");
	public JLabel labelinfoStage = new JLabel("En attente");
	public JLabel LabelAffiche;
	public BorderLayout border = new BorderLayout();
	Offre myoffre;

	public ChoixStageJPanel(Offre offre) {

		super();

		myoffre = offre;
		EntrepriseDAO entrDAO = new EntrepriseDAO();
		DomaineDAO domaDAO = new DomaineDAO();

		Entreprise entreprise = entrDAO.find(offre.getIdEntreprise());
		Domaine domaine = domaDAO.find(offre.getIdDomaine());

		nomImage = entreprise.getLogo();
		ImageIcon ImageAfficheFilm = new ImageIcon(nomImage);
		ImageAffiche = scaleImage(ImageAfficheFilm.getImage(), 160);
		LabelAffiche = new JLabel(new ImageIcon(ImageAffiche));
		this.add(LabelAffiche, layout.WEST);

		titre.setText(offre.getNomOffre());
		titre.setFont(police);

		boite.setText("Entreprise : " + entreprise.getNom());
		boite.setFont(police);
		;

		Ldomaine.setText("\nDomaine : " + domaine.getNom());
		Ldomaine.setFont(police);

		ImageIcon ImageAfficheFilm1 = new ImageIcon(nomImage);
		ImageAffiche = scaleImage(ImageAfficheFilm1.getImage(), 160);
		LabelAffiche = new JLabel(new ImageIcon(ImageAffiche));
		build();
	}

	public void build() {

		this.setLayout(layout);
		this.add(LabelAffiche, layout.WEST);

		this.infoStage.setLayout(new GridLayout(3, 1, 30, -30));
		this.infoStage.add(titre);
		this.infoStage.add(boite);
		this.infoStage.add(Ldomaine);

		this.titre.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		this.boite.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		this.Ldomaine.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

		this.add(infoStage, layout.CENTER);
		this.add(panelBouton, layout.EAST);

		this.setBackground(Fenetre.couleurBlanc);
		infoStage.setBackground(Fenetre.couleurBlanc);
		panelBouton.setBackground(Fenetre.couleurBlanc);

		this.panelBouton.add(selectionner);

		selectionner.addMouseListener(new MouseListener() {
			public void mouseReleased(MouseEvent arg0) {
			}

			public void mousePressed(MouseEvent e) {

				if (myself.selectionner.getText().equals("Selectionner")) {
					Fenetre.level_3 = new JPanelOffre(myoffre);
					Fenetre.mainPanel.add(Fenetre.level_3, "level_3");
					Fenetre.cardLayout.show(Fenetre.mainPanel, "level_3");
				}
				if (myself.selectionner.getText().equals("Retourner aux offres")) {
					Fenetre.cardLayout.show(Fenetre.mainPanel, "level_2");
				}
			}

			public void mouseExited(MouseEvent arg0) {

			}

			public void mouseEntered(MouseEvent arg0) {
				myself.setBackground(Fenetre.couleurGrise);
				panelBouton.setBackground(Fenetre.couleurGrise);
				infoStage.setBackground(Fenetre.couleurGrise);
			}

			public void mouseClicked(MouseEvent arg0) {

			}
		});

		this.setPreferredSize(new Dimension(120, 120));
		this.addMouseListener(new MouseListener() {

			public void mouseClicked(MouseEvent arg0) {

			}

			public void mouseEntered(MouseEvent arg0) {
				myself.setBackground(Fenetre.couleurGrise);
				panelBouton.setBackground(Fenetre.couleurGrise);
				infoStage.setBackground(Fenetre.couleurGrise);

			}

			public void mouseExited(MouseEvent arg0) {
				myself.setBackground(Fenetre.couleurBlanc);
				panelBouton.setBackground(Fenetre.couleurBlanc);
				infoStage.setBackground(Fenetre.couleurBlanc);

			}

			public void mousePressed(MouseEvent arg0) {
				
			}

			public void mouseReleased(MouseEvent arg0) {
			
			}

		});
	}

	// Fonctions pour adapter les images au panel

	public static Image scaleImage(Image source, int width, int height) {
		BufferedImage img = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
		Graphics2D g = (Graphics2D) img.getGraphics();
		g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
		g.drawImage(source, 0, 0, width, height, null);
		g.dispose();
		return img;
	}

	public static Image scaleImage(Image source, int size) {
		int width = source.getWidth(null);
		int height = source.getHeight(null);
		double f = 0;
		if (width < height) {// portrait
			f = (double) height / (double) width;
			width = (int) (size / f);
			height = size;
		} else {// paysage
			f = (double) width / (double) height;
			width = size;
			height = (int) (size / f);
		}
		return scaleImage(source, width, height);
	}

}
