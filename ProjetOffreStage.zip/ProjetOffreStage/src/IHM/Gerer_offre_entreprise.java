package IHM;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;

import DAO.StageDAO;
import Objet.Offre;
import Objet.Stage;

public class Gerer_offre_entreprise extends ChoixStageJPanel {

	StageDAO stagDAO;
	Offre offre;
	ArrayList<Stage> list_stage;

	public Gerer_offre_entreprise(final Offre offre) {
		super(offre);

		stagDAO = new StageDAO();

		boite.setText("Nombre de Postulant : " + stagDAO.getAll_stage_by_offre(myoffre.getId()).size());

		selectionner.setText("Modifier");
		JButton candidat = new JButton("Voir les candidats");
		panelBouton.add(candidat);
		list_stage = (ArrayList<Stage>) stagDAO.getAll_stage_by_offre(offre.getId());

		candidat.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {
				Fenetre.level_3 = new Choisir_candidat_panel(offre);
				Fenetre.mainPanel.add(Fenetre.level_3, "level_3");
				Fenetre.cardLayout.show(Fenetre.mainPanel, "level_3");
			}

		});

		selectionner.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				Fenetre.level_3 = new Modifier_Offre(myoffre);
				Fenetre.mainPanel.add(Fenetre.level_3, "level_3");
				Fenetre.cardLayout.show(Fenetre.mainPanel, "level_3");
			}
		});
	}

}
