package IHM;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;

import DAO.EntrepriseDAO;
import DAO.OffreDAO;
import Objet.Offre;

public class ProfilPanel_Entreprise extends ProfilPanel_Etudiant{
	
	JPanel panelTel = new JPanel();
	JLabel tel = new JLabel("Telephone : ");
	JLabel tel1 = new JLabel();
	JTextField texfieldTel;
	EntrepriseDAO entrDAO = new EntrepriseDAO();

	public ProfilPanel_Entreprise(String nom, String email, int idAdresse, int idSecurite) {
		super(null, nom, email, idAdresse, idSecurite);
		
		info.removeAll();
		boutonPanel.setLayout(new GridLayout(1, 3));
		boutonPanel.remove(p4);
		postulation.setText("Voir mes offres");
		
		p1.add(quitter);
		p2.add(modifier);
		p3.add(postulation);
		
		tel1.setText(Fenetre.getEntrepriseLog().getTel());
		tel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		tel.setFont(policeTimesRoman);
		panelTel.setBackground(Color.white);
		texfieldTel = new JTextField(Fenetre.getEntrepriseLog().getTel());
		
		panelTel.add(tel);
		tel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		tel.setFont(policeTimesRoman);
		panelTel.add(tel1);
		panelTel.setLayout(new GridLayout(1, 2));
		
		info.add(panelNom);
		info.add(panelLogin);
		info.add(panelAdresse);
		info.add(panelEmail);
		info.add(panelTel);
		info.add(panelMdp);
		info.add(panelVille);
		
		postulation.removeActionListener(postulation.getActionListeners()[0]);
		modifier.removeActionListener(modifier.getActionListeners()[0]);
		
		postulation.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent arg0) {
				OffreDAO offrDao = new OffreDAO();
				Fenetre.level_2 = new ConsulterPanel(
						(ArrayList<Offre>) offrDao.getAll_Entreprise(Fenetre.getEntrepriseLog().getId()), ConsulterPanel.constante_entreprise);
				Fenetre.mainPanel.add(Fenetre.level_2, "level_2");
				Fenetre.cardLayout.show(Fenetre.mainPanel, "level_2");
			}
		});
		
		modifier.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				if (flag) {

					panelNom.remove(Nom1);
					panelNom.add(texfieldNom);

					panelTel.remove(tel1);
					panelTel.add(texfieldTel);
					
					panelLogin.remove(Login1);
					panelLogin.add(texfieldPseudo);

					panelAdresse.remove(Adresse1);
					panelAdresse.add(texfieldAdresse);

					panelMdp.remove(Mdp1);
					panelMdp.add(texfieldMdp);

					panelVille.remove(Ville1);
					panelVille.add(texfieldVille);

					panelEmail.remove(Email1);
					panelEmail.add(texfieldEmail);
					
					testMDP = texfieldMdp.getText();

					modifier.setText("Enregistrer les modifications");
					flag = false;
					SwingUtilities.updateComponentTreeUI(me);
				}

				/*
				 * 2eme �tape : Enregistrer les modifications : Si les
				 * textfields saisis sont differents des attributs initial du
				 * client , ces meme atribut sont modifi�s , les textifields
				 * sont finalement supprim� pour revenir aux labels affichant
				 * les nouvelles informations
				 */

				else if (!flag) {

					if (!texfieldNom.getText().equals(Fenetre.getEntrepriseLog().getNom())) {
						Fenetre.getEntrepriseLog().setNom(texfieldNom.getText());
						Nom1.setText(texfieldNom.getText());
					}
					panelNom.remove(texfieldNom);
					panelNom.add(Nom1);


					if (!texfieldPseudo.getText().equals(securiteLog.getLogin())) {
						securiteLog.setLogin(texfieldPseudo.getText());
						Login1.setText(texfieldPseudo.getText());
					}
					panelLogin.remove(texfieldPseudo);
					panelLogin.add(Login1);

					if (!texfieldAdresse.getText().equals(adresseLog.getRue())) {
						adresseLog.setRue(texfieldAdresse.getText());
						Adresse1.setText(texfieldAdresse.getText());
					}
					panelAdresse.remove(texfieldAdresse);
					panelAdresse.add(Adresse1);
					
					if (!texfieldVille.getText().equals(adresseLog.getVille())) {
						adresseLog.setVille(texfieldVille.getText());
						Ville1.setText(texfieldVille.getText());
					}
					panelVille.remove(texfieldVille);
					panelVille.add(Ville1);

					if (!texfieldEmail.getText().equals(Fenetre.getEntrepriseLog().getEmail())) {
						Fenetre.getEntrepriseLog().setEmail(texfieldEmail.getText());
						Email1.setText(texfieldEmail.getText());
					}
					panelEmail.remove(texfieldEmail);
					panelEmail.add(Email1);
					
					if (!texfieldTel.getText().equals(Fenetre.getEntrepriseLog().getTel())) {
						Fenetre.getEntrepriseLog().setTel(texfieldTel.getText());
						tel1.setText(texfieldTel.getText());
					}
					panelTel.remove(texfieldTel);
					panelTel.add(tel1);

					if (!testMDP.equals(texfieldMdp.getText())) {
						md5.pass(texfieldMdp.getText());
						securiteLog.setMdp(md5.getCode());
					}
					panelMdp.remove(texfieldMdp);
					panelMdp.add(Mdp1);

					modifier.setText("Modifier");

						entrDAO.update(Fenetre.getEntrepriseLog());
						adreDAO.update(adresseLog);
						secuDAO.update(securiteLog);
						flag = true;
						SwingUtilities.updateComponentTreeUI(me);
					}
				}
		});
	}

}
