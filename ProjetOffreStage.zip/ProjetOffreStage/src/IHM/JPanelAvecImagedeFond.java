package IHM;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import javax.swing.ImageIcon;
import javax.swing.JPanel;

// Permet de creer un panel avec un fond grace a drawImage()

public class JPanelAvecImagedeFond extends JPanel {

	Image fond;

	public JPanelAvecImagedeFond(String nomImage, int width, int height) {

		ImageIcon ImageAfficheFilm = new ImageIcon(nomImage);
		fond = scaleImage(ImageAfficheFilm.getImage(), width, height);

	}

	public JPanelAvecImagedeFond(String nomImage) {

		ImageIcon ImageAfficheFilm = new ImageIcon(nomImage);
		fond = scaleImage(ImageAfficheFilm.getImage(), 800);
	}

	public JPanelAvecImagedeFond(String nomImage, int taille) {

		ImageIcon ImageAfficheFilm = new ImageIcon(nomImage);
		fond = scaleImage(ImageAfficheFilm.getImage(), taille);
	}

	public void paintComponent(Graphics g) {
		g.drawImage(fond, 0, 0, null);
	}

	public static Image scaleImage(Image source, int width, int height) {
		BufferedImage img = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
		Graphics2D g = (Graphics2D) img.getGraphics();
		g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
		g.drawImage(source, 0, 0, width, height, null);
		g.dispose();
		return img;
	}

	public static Image scaleImage(Image source, int size) {
		int width = source.getWidth(null);
		int height = source.getHeight(null);
		double f = 0;
		if (width < height) {// portrait
			f = (double) height / (double) width;
			width = (int) (size / f);
			height = size;
		} else {// paysage
			f = (double) width / (double) height;
			width = size;
			height = (int) (size / f);
		}
		return scaleImage(source, width, height);
	}
}
