package IHM.Acceuil;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

import Action.ActionButtonDeco;
import DAO.OffreDAO;
import IHM.JTable.JTableEntreprise;
import IHM.JTable.JTableEtudiant;
import IHM.JTable.JTableOffre;
import Objet.Administrateur;

/*Page d'acceuil d'un administrateur */

public class Acceuil_Admin extends JPanel {

	JButton buttonGererEntreprise;
	JButton buttonGererEtudiant;
	JButton buttonGererOffre;
	JButton buttonDeco;

	JPanel gerer_entr;
	JPanel gerer_etud;
	JPanel gerer_offr;
	JPanel quitter;
	JPanel centerPanel;
	OffreDAO offrDao;
	ArrayList list;

	JLabel img_profil;
	JLabel img_creer;
	JLabel img_gerer;
	JLabel img_quitter;

	public Image ImageAffiche1;
	public Image ImageAffiche2;
	public Image ImageAffiche3;
	public Image ImageAffiche4;

	BorderLayout border = new BorderLayout();
	Font policeTimesRoman = new Font(" TimesRoman ", Font.BOLD, 15);
	GridLayout grid = new GridLayout(2, 2);
	Color bleu = new Color(255, 255, 255);

	public Acceuil_Admin(Administrateur log) {

		/* les boutons */
		JButton buttonDeco = new JButton("Se deconnecter");
		buttonGererEntreprise = new JButton("Gerer les entreprises");
		buttonGererEtudiant = new JButton("Gerer les etudiants");
		buttonGererOffre = new JButton("Gerer les offres");

		/* les quatres panel qui representent les options */
		this.gerer_offr = new JPanel();
		this.gerer_etud = new JPanel();
		this.gerer_entr = new JPanel();
		this.quitter = new JPanel();

		centerPanel = new JPanel();
		this.centerPanel.setLayout(grid);
		this.centerPanel.add(gerer_offr);
		this.centerPanel.add(gerer_etud);
		this.centerPanel.add(gerer_entr);
		this.centerPanel.add(quitter);

		grid.setVgap(5);
		grid.setHgap(5);
		centerPanel.setBackground(new Color(187, 222, 251));
		gerer_offr.setBackground(bleu);
		gerer_etud.setBackground(bleu);
		gerer_entr.setBackground(bleu);
		quitter.setBackground(bleu);

		this.setLayout(border);
		this.add(centerPanel, border.CENTER);

		/* Creation et ajout des images */
		
		String lien1 = "images\\edit_offre.png";
		ImageIcon ImageAfficheFilm1 = new ImageIcon(lien1);
		ImageAffiche1 = scaleImage(ImageAfficheFilm1.getImage(), 160);
		img_creer = new JLabel(new ImageIcon(ImageAffiche1));
		this.gerer_offr.add(img_creer);
		this.gerer_offr.add(buttonGererOffre);

		String lien2 = "images\\edit_etudiant.png";
		ImageIcon ImageAfficheFilm2 = new ImageIcon(lien2);
		ImageAffiche2 = scaleImage(ImageAfficheFilm2.getImage(), 160);
		img_gerer = new JLabel(new ImageIcon(ImageAffiche2));
		this.gerer_etud.add(img_gerer);
		this.gerer_etud.add(buttonGererEtudiant);

		String lien3 = "images\\edit_entreprise.png";
		;
		ImageIcon ImageAfficheFilm3 = new ImageIcon(lien3);
		ImageAffiche3 = scaleImage(ImageAfficheFilm3.getImage(), 160);
		img_profil = new JLabel(new ImageIcon(ImageAffiche3));
		this.gerer_entr.add(img_profil);
		this.gerer_entr.add(buttonGererEntreprise);

		String lien4 = "images\\quitter.png";
		ImageIcon ImageAfficheFilm4 = new ImageIcon(lien4);
		ImageAffiche4 = scaleImage(ImageAfficheFilm4.getImage(), 160);
		img_quitter = new JLabel(new ImageIcon(ImageAffiche4));
		this.quitter.add(img_quitter);
		this.quitter.add(buttonDeco);

		offrDao = new OffreDAO();
		list = new ArrayList();

		buttonGererEntreprise.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new JTableEntreprise();

			}
		});

		buttonGererEtudiant.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new JTableEtudiant();

			}
		});

		buttonGererOffre.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new JTableOffre();

			}
		});
		buttonDeco.addActionListener(new ActionButtonDeco());
	}

	public static Image scaleImage(Image source, int width, int height) {
		BufferedImage img = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
		Graphics2D g = (Graphics2D) img.getGraphics();
		g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
		g.drawImage(source, 0, 0, width, height, null);
		g.dispose();
		return img;
	}

	public static Image scaleImage(Image source, int size) {
		int width = source.getWidth(null);
		int height = source.getHeight(null);
		double f = 0;
		if (width < height) {// portrait
			f = (double) height / (double) width;
			width = (int) (size / f);
			height = size;
		} else {// paysage
			f = (double) width / (double) height;
			width = size;
			height = (int) (size / f);
		}
		return scaleImage(source, width, height);
	}
}
