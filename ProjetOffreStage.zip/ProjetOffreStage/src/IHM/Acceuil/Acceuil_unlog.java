package IHM.Acceuil;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;

import DAO.EntrepriseDAO;
import DAO.EtudiantDAO;
import IHM.JDialogLogin;
import IHM.JPanelAvecImagedeFond;
import Objet.Administrateur;
import Objet.Entreprise;
import Objet.Etudiant;

/* Page d'acceuil en mode non connect� , il s'agit en faite d'une simple
 * image avec des boutons en set bounds positionn�s par dessus*/

public class Acceuil_unlog extends JDialog {

	BorderLayout border = new BorderLayout();
	JButton etudiant = new JButton(new ImageIcon("images//acceul_etudiant.png"));
	JButton entreprise = new JButton(new ImageIcon(
			"images//acceuil_entreprise.png"));
	JButton admin = new JButton(new ImageIcon("images//acceuil_univ.png"));
	JPanel south_bouton;
	EntrepriseDAO entrDAO = new EntrepriseDAO();
	EtudiantDAO etudDAO = new EtudiantDAO();
	static JDialog me;

	
	public Acceuil_unlog() {
		super();

		this.setSize(744, 581);
		this.setTitle("Identification client");
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		build();
		this.setVisible(true);
		me = this;
	}

	void build() {
		JPanel mainPanel = new JPanelAvecImagedeFond(
				"images//acceuilstage.jpg", 744, 581);
		this.add(mainPanel);
		south_bouton = new JPanel();
		south_bouton.setLayout(new GridLayout(1, 3, 5, 5));

		JPanel p1 = new JPanel();
		JPanel p2 = new JPanel();
		JPanel p3 = new JPanel();
		
		mainPanel.setLayout(null);
		mainPanel.add(etudiant);
		mainPanel.add(entreprise);
		mainPanel.add(admin);
		etudiant.  setBounds(90, 330, 130, 130);
		entreprise.setBounds(310,330, 130, 130);
		admin.	   setBounds(545,330, 130, 130);
		p1.setOpaque(true);
		south_bouton.add(p1);
		south_bouton.add(p2);
		south_bouton.add(p3);
		mainPanel.add(south_bouton, border.SOUTH);
		
		
		admin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new JDialogLogin(new Administrateur());
				
				
			}
		});
		
		// log etudiant
				etudiant.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						
						new JDialogLogin(new Etudiant());
					}
				});
				
				//log entreprise
				entreprise.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						new JDialogLogin(new Entreprise());
					}
				});
				
				
	}
	
	public static void closeUnlog(){
		me.setVisible(false);
	}
}
