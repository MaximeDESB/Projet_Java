package IHM.Acceuil;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import Autre.Md5;
import DAO.AdministrateurDAO;
import DAO.EntrepriseDAO;
import DAO.EtudiantDAO;
import DAO.SecuriteDAO;
import IHM.Fenetre;
import IHM.JPanelAvecImagedeFond;
import IHM.Acceuil.Acceuil_Admin;
import IHM.Acceuil.Acceuil_Entreprise;
import IHM.Acceuil.Acceuil_Etudiant;
import IHM.Acceuil.Acceuil_unlog;
import Objet.Administrateur;
import Objet.Entreprise;
import Objet.Etudiant;
import Objet.Securite;

public class JDialogLogin extends JDialog {

	JPanelAvecImagedeFond fond;
	JPanel J2 = new JPanel();
	JPanel J3 = new JPanel();
	JPanel J4 = new JPanel();
	JPanel vide = new JPanel();
	JPanel vide2 = new JPanel();
	Font policeTimesRoman = new Font(" TimesRoman ", Font.BOLD, 15);

	SecuriteDAO secuDAO = new SecuriteDAO();
	EtudiantDAO etuDAO = new EtudiantDAO();
	EntrepriseDAO entrDAO = new EntrepriseDAO();
	AdministrateurDAO adminDAO = new AdministrateurDAO();
	Md5 md5 = new Md5();

	JLabel login = new JLabel("         Login : ");
	JLabel MDP = new JLabel("          MDP : ");
	Securite secu;
	JButton seconnecter = new JButton("Se connecter");

	JTextField saisieID = new JTextField();
	JPasswordField saisieMDP = new JPasswordField();
	String password;
	JDialogLogin me;
	boolean flag = false;

	// si on a selectionn� etudiant

	public JDialogLogin(Etudiant etudiant) {

		super();
		me = this;
		this.setSize(350, 230);
		this.setTitle("Identification client");
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		fond = new JPanelAvecImagedeFond("images\\fond.jpg", me.getWidth(),
				me.getHeight());
		build();
		this.setVisible(true);

		saisieMDP.addKeyListener(new KeyListener() {

			@Override
			public void keyTyped(KeyEvent evt) {
				if (evt.getKeyChar() == KeyEvent.VK_ENTER)
					seconnecter.doClick();

			}

			@Override
			public void keyReleased(KeyEvent arg0) {
				// TODO Auto-generated method stub

			}

			@Override
			public void keyPressed(KeyEvent arg0) {
				// TODO Auto-generated method stub

			}
		});

		seconnecter.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent event) {
				md5.pass(new String(saisieMDP.getPassword()));

				// transforme le mot de passe en md5
				password = md5.getCode();

				ArrayList<Etudiant> liste = (ArrayList<Etudiant>) etuDAO
						.getAll();
				for (Etudiant a : liste) {
					secu = secuDAO.find(a.getIdSecurite());

					// test le mot de passe et le login
					if (secu.getLogin().equals(saisieID.getText())
							&& secu.getMdp().equals(password)) {
						flag = true;
						new Fenetre();
						Fenetre.setEtudiantLog(a);
						Fenetre.level_1 = new Acceuil_Etudiant(a);
						Fenetre.mainPanel.add(Fenetre.level_1, "level_1");
						Fenetre.cardLayout.show(Fenetre.mainPanel, "level_1");

						me.setVisible(false);
						Acceuil_unlog.closeUnlog();
					}
				}

				if (!flag) {
					JOptionPane.showMessageDialog(null,
							"Login ou mot de passe incorrect", "Information",
							JOptionPane.ERROR_MESSAGE);
				}
			}
		});

	}

	public JDialogLogin(Administrateur admin) {
		super();
		me = this;
		this.setSize(350, 230);
		this.setTitle("Identification client");
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		fond = new JPanelAvecImagedeFond("images\\fond_vert.jpg",
				me.getWidth(), me.getHeight());
		login.setForeground(new Color(255, 255, 255));
		MDP.setForeground(new Color(255, 255, 255));
		build();
		this.setVisible(true);

		saisieMDP.addKeyListener(new KeyListener() {

			@Override
			public void keyTyped(KeyEvent evt) {
				if (evt.getKeyChar() == KeyEvent.VK_ENTER)
					seconnecter.doClick();

			}

			@Override
			public void keyReleased(KeyEvent arg0) {
				// TODO Auto-generated method stub

			}

			@Override
			public void keyPressed(KeyEvent arg0) {
				// TODO Auto-generated method stub

			}
		});

		seconnecter.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent event) {

				md5.pass(new String(saisieMDP.getPassword()));
				password = md5.getCode();

				ArrayList<Administrateur> liste = (ArrayList<Administrateur>) adminDAO
						.getAll();
				for (Administrateur a : liste) {
					secu = secuDAO.find(a.getIdSecurite());
					if (secu.getLogin().equals(saisieID.getText())
							&& secu.getMdp().equals(password)) {
						flag = true;
						new Fenetre();
						Fenetre.level_1 = new Acceuil_Admin(a);
						Fenetre.mainPanel.add(Fenetre.level_1, "level_1");
						Fenetre.cardLayout.show(Fenetre.mainPanel, "level_1");
						me.setVisible(false);
						Acceuil_unlog.closeUnlog();

					}
				}
				if (!flag) {
					JOptionPane.showMessageDialog(null,
							"Login ou mot de passe incorrect", "Information",
							JOptionPane.ERROR_MESSAGE);
				}

			}
		});

	}

	public JDialogLogin(Entreprise entre) {
		super();
		me = this;
		this.setSize(350, 230);
		this.setTitle("Identification client");
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		fond = new JPanelAvecImagedeFond("images\\fond_rouge.jpg",
				me.getWidth(), me.getHeight());
		login.setForeground(new Color(255, 255, 255));
		MDP.setForeground(new Color(255, 255, 255));

		build();
		this.setVisible(true);

		saisieMDP.addKeyListener(new KeyListener() {

			@Override
			public void keyTyped(KeyEvent evt) {
				if (evt.getKeyChar() == KeyEvent.VK_ENTER)
					seconnecter.doClick();

			}

			@Override
			public void keyReleased(KeyEvent arg0) {
				// TODO Auto-generated method stub

			}

			@Override
			public void keyPressed(KeyEvent arg0) {
				// TODO Auto-generated method stub

			}
		});

		seconnecter.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent event) {
				md5.pass(new String(saisieMDP.getPassword()));
				password = md5.getCode();

				ArrayList<Entreprise> liste = (ArrayList<Entreprise>) entrDAO
						.getAll();
				for (Entreprise a : liste) {
					secu = secuDAO.find(a.getIdSecurite());
					if (secu.getLogin().equals(saisieID.getText())
							&& secu.getMdp().equals(password)) {
						flag = true;
						new Fenetre();
						Fenetre.setEntrepriseLog(a);
						Fenetre.level_1 = new Acceuil_Entreprise(a);
						Fenetre.mainPanel.add(Fenetre.level_1, "level_1");
						Fenetre.cardLayout.show(Fenetre.mainPanel, "level_1");
						me.setVisible(false);
						Acceuil_unlog.closeUnlog();

					}
				}
				if (!flag) {
					JOptionPane.showMessageDialog(null,
							"Login ou mot de passe incorrect", "Information",
							JOptionPane.ERROR_MESSAGE);
				}

			}
		});

	}

	public void build() {

		this.add(fond);

		fond.setLayout(new GridLayout(5, 1));
		fond.add(vide);
		fond.add(J2);
		fond.add(J3);
		fond.add(J4);
		fond.add(vide2);

		vide.setOpaque(false);
		vide2.setOpaque(false);
		J2.setOpaque(false);
		J3.setOpaque(false);
		J4.setOpaque(false);

		J2.setBounds(20, 40, 200, 20);

		saisieID.setPreferredSize(new Dimension(150, 20));
		saisieMDP.setPreferredSize(new Dimension(150, 20));

		login.setFont(policeTimesRoman);
		MDP.setFont(policeTimesRoman);
		seconnecter.setFont(policeTimesRoman);
		J2.add(login);
		J2.add(saisieID);
		J3.add(MDP);
		J3.add(saisieMDP);
		J4.add(seconnecter);

	}

}
