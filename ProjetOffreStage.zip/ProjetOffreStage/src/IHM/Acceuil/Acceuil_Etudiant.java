package IHM.Acceuil;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.LayoutManager;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.util.ArrayList;

import javax.swing.AbstractAction;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.SwingUtilities;

import Action.ActionButtonDeco;
import DAO.EtudiantDAO;
import DAO.OffreDAO;
import DAO.StageDAO;
import IHM.ConsulterPanel;
import IHM.Fenetre;
import IHM.ProfilPanel_Etudiant;
import Objet.Etudiant;
import Objet.Offre;
import Objet.Stage;

/* Page d'acceuil, la construction est similaire a Acceuil_Admin */

public class Acceuil_Etudiant extends JPanel {

	JButton buttonCreerOffre;
	JButton buttonGererEntreprise;
	JButton buttonGererEtudiant;
	JButton buttonConsulterOffre;
	JButton buttonGererOffre;
	JButton buttonMonProfil;
	JButton buttonDeco;

	JPanel consulter;
	JPanel gerer;
	JPanel profil;
	JPanel quitter;
	JPanel centre_gerer;
	JPanel panelNouveau;

	OffreDAO offrDao;
	ArrayList<Offre> list;

	JLabel nouveau;
	JLabel img_profil;
	JLabel img_consulter;
	JLabel img_gerer;
	JLabel img_quitter;

	public Image ImageAffiche1;
	public Image ImageAffiche2;
	public Image ImageAffiche3;
	public Image ImageAffiche4;
	GridLayout grid = new GridLayout(2, 2, 5, 5);
	Color bleu_clair = new Color(187, 222, 251);
	Color bleu = new Color(255, 255, 255);

	public Acceuil_Etudiant(final Etudiant log) {

		new BorderLayout();
		buttonConsulterOffre = new JButton("Consulter les offres");
		buttonMonProfil = new JButton("Mon Profil");
		buttonGererOffre = new JButton("Gerer mes candidatures");
		buttonDeco = new JButton("Se deconnecter");
		nouveau = new JLabel("Vous avez un nouveau stage !");

		consulter = new JPanel();
		gerer = new JPanel();
		profil = new JPanel();
		quitter = new JPanel();
		centre_gerer = new JPanel();
		panelNouveau = new JPanel();

		this.setLayout(grid);
		gerer.setLayout(new BorderLayout());

		this.setBackground(bleu_clair);
		centre_gerer.setBackground(bleu);
		profil.setBackground(bleu);
		consulter.setBackground(bleu);
		quitter.setBackground(bleu);
		panelNouveau.setBackground(bleu);

		this.add(consulter);
		this.add(gerer);
		this.add(profil);
		this.add(quitter);

		panelNouveau.add(nouveau);
		nouveau.setForeground(Color.RED);

		String lien1 = "images\\consulter.png";
		ImageIcon ImageAfficheFilm1 = new ImageIcon(lien1);
		ImageAffiche1 = scaleImage(ImageAfficheFilm1.getImage(), 160);
		img_consulter = new JLabel(new ImageIcon(ImageAffiche1));
		this.consulter.add(img_consulter);
		this.consulter.add(buttonConsulterOffre);

		String lien2 = "images\\gerer.png";
		ImageIcon ImageAfficheFilm2 = new ImageIcon(lien2);
		ImageAffiche2 = scaleImage(ImageAfficheFilm2.getImage(), 160);
		img_gerer = new JLabel(new ImageIcon(ImageAffiche2));
		centre_gerer.add(img_gerer);
		centre_gerer.add(buttonGererOffre);
		gerer.add(centre_gerer, BorderLayout.CENTER);
		
		if (Fenetre.getEtudiantLog().getNouveauStage())
		gerer.add(panelNouveau, BorderLayout.SOUTH);

		String lien3 = "images\\profil.png";
		ImageIcon ImageAfficheFilm3 = new ImageIcon(lien3);
		ImageAffiche3 = scaleImage(ImageAfficheFilm3.getImage(), 160);
		img_profil = new JLabel(new ImageIcon(ImageAffiche3));
		this.profil.add(img_profil);
		this.profil.add(buttonMonProfil);

		String lien4 = "images\\quitter.png";
		ImageIcon ImageAfficheFilm4 = new ImageIcon(lien4);
		ImageAffiche4 = scaleImage(ImageAfficheFilm4.getImage(), 160);
		img_quitter = new JLabel(new ImageIcon(ImageAffiche4));
		this.quitter.add(img_quitter);
		this.quitter.add(buttonDeco);

		offrDao = new OffreDAO();
		list = new ArrayList<Offre>();

		buttonMonProfil.addActionListener(new AbstractAction() {

			public void actionPerformed(ActionEvent arg0) {

				Etudiant log = Fenetre.getEtudiantLog();
				Fenetre.level_2 = new ProfilPanel_Etudiant(log.getPrenom(), log.getNom(), log.getEmail(),
						log.getIdAdresse(), log.getIdSecurite());
				Fenetre.mainPanel.add(Fenetre.level_2, "level_2");
				Fenetre.cardLayout.show(Fenetre.mainPanel, "level_2");
			}

		});
		buttonGererOffre.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {
				Fenetre.getEtudiantLog().setNouveauStage(false);

				EtudiantDAO etudDAO = new EtudiantDAO();
				etudDAO.update(Fenetre.getEtudiantLog());
				StageDAO stagDAO = new StageDAO();
				new OffreDAO();
				new ArrayList<Object>();
				ArrayList<Stage> list = (ArrayList<Stage>) stagDAO
						.getAll_stage_by_etudiant((Fenetre.getEtudiantLog().getId()));

				Fenetre.levelScroll = new JScrollPane(new ConsulterPanel(list, "a"));
				Fenetre.mainPanel.add(Fenetre.levelScroll, "level_scroll");
				Fenetre.cardLayout.show(Fenetre.mainPanel, "level_scroll");
			}

		});
		buttonConsulterOffre.addActionListener(new AbstractAction() {

			public void actionPerformed(ActionEvent arg0) {

				list = (ArrayList<Offre>) offrDao.getAll();
				Fenetre.levelScroll = new JScrollPane(
						new ConsulterPanel(list, ConsulterPanel.constante_consulter_offre_etudiant));
				Fenetre.mainPanel.add(Fenetre.levelScroll, "level_scroll");
				Fenetre.cardLayout.show(Fenetre.mainPanel, "level_scroll");

			}

		});
		buttonDeco.addActionListener(new ActionButtonDeco());
		SwingUtilities.updateComponentTreeUI(this);
	}
	// Fonctions pour adapter les images au panel

	public static Image scaleImage(Image source, int width, int height) {
		BufferedImage img = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
		Graphics2D g = (Graphics2D) img.getGraphics();
		g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
		g.drawImage(source, 0, 0, width, height, null);
		g.dispose();
		return img;
	}

	public static Image scaleImage(Image source, int size) {
		int width = source.getWidth(null);
		int height = source.getHeight(null);
		double f = 0;
		if (width < height) {// portrait
			f = (double) height / (double) width;
			width = (int) (size / f);
			height = size;
		} else {// paysage
			f = (double) width / (double) height;
			width = size;
			height = (int) (size / f);
		}
		return scaleImage(source, width, height);
	}

}
