package IHM;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

import DAO.OffreDAO;
import IHM.Acceuil.Acceuil_Etudiant;
import Objet.Offre;
import Objet.Stage;

public class ConsulterPanel extends JPanel {

	public final static int constante_entreprise = 1;
	public final static int constante_consulter_offre_etudiant = 2;
	public final static int constante_consulter_candidature_etudiant = 3;

	BorderLayout border = new BorderLayout();
	OffreDAO offrDAO = new OffreDAO();
	JLabel texte;
	JPanel boutonPanel = new JPanel();
	JPanel vide = new JPanel();
	Font policeTimesRoman = new Font(" TimesRoman ", Font.BOLD, 35);

	public ConsulterPanel(ArrayList<Offre> list_offre, int i) {
		this.setBackground(new Color(187, 222, 251));
		if (i == 1) {

			build_entreprise(list_offre);

		} /* Pour que l'etudiant voie les offres disponibles */
		if (i == 2) {

			build_consulter_offre_etudiant(list_offre);
		}
	}

	// Pour que l'etudiant gere ses candidatures
	public ConsulterPanel(ArrayList<Stage> list_stage, String a) {
		this.setBackground(new Color(187, 222, 251));

		
		/* Banniere */
		JPanelAvecImagedeFond banniere = new JPanelAvecImagedeFond("images\\fond2.jpg");
		texte = new JLabel("Gerer mes candidatures");
		texte.setHorizontalAlignment(SwingConstants.CENTER);
		texte.setVerticalAlignment(SwingConstants.CENTER);
		texte.setFont(policeTimesRoman);
		banniere.setLayout(new BorderLayout());
		banniere.add(texte, BorderLayout.CENTER);
		banniere.add(vide, BorderLayout.WEST);
		JButton retour = new JButton("Retour");
		boutonPanel.add(retour);
		banniere.add(boutonPanel, BorderLayout.EAST);
		boutonPanel.setOpaque(false);
		vide.setOpaque(false);
		vide.setPreferredSize(new Dimension(85, 125));
		this.add(banniere);

		int i = 0;
		for (Stage s : list_stage) {

			// le i+1 permet a la classe de connaitre son identifiant pour se
			// supprimer grace au this (son pere)

			this.add(new ConsulterCandidature_Etudiant(s, i + 1, this));
			i++;
		}
		retour.addActionListener((new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {
				Fenetre.mainPanel.remove(Fenetre.level_1);
				Fenetre.level_1 = new Acceuil_Etudiant(Fenetre.getEtudiantLog());
				Fenetre.mainPanel.add(Fenetre.level_1, "level_1");
				Fenetre.cardLayout.show(Fenetre.mainPanel, "level_1");

			}
		}));
		
		if (list_stage.size() <= 2)
			this.setLayout(new GridLayout(4, 1, 5, 5));
		else
			this.setLayout(new GridLayout(i + 1, 1, 5, 5));
	}

	/* Pour que l'etudiant voie les offres disponibles */
	void build_consulter_offre_etudiant(ArrayList<Offre> list_offre) {
		this.setBackground(new Color(187, 222, 251));
		JPanelAvecImagedeFond banniere = new JPanelAvecImagedeFond("images\\fond2.jpg");
		texte = new JLabel("Voir les offres");
		texte.setHorizontalAlignment(SwingConstants.CENTER);
		texte.setVerticalAlignment(SwingConstants.CENTER);
		texte.setFont(policeTimesRoman);
		banniere.setLayout(new BorderLayout());
		banniere.add(texte, BorderLayout.CENTER);
		banniere.add(vide, BorderLayout.WEST);
		JButton retour = new JButton("Retour");
		boutonPanel.add(retour);
		banniere.add(boutonPanel, BorderLayout.EAST);
		boutonPanel.setOpaque(false);
		vide.setOpaque(false);
		vide.setPreferredSize(new Dimension(85, 125));
		this.add(banniere);

		int i = 0;
		for (Offre ofr : list_offre) {

			ChoixStageJPanel choix = new ChoixStageJPanel(list_offre.get(i));

			this.add(choix);
			i++;
		}

		if (list_offre.size() <= 2)
			this.setLayout(new GridLayout(4, 1, 5, 5));
		else
			this.setLayout(new GridLayout(i + 1, 1, 5, 5));
		retour.addActionListener((new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {
				Fenetre.cardLayout.show(Fenetre.mainPanel, "level_1");

			}
		}));
	}

	/* Panel pour Entreprise : Gerer mes offres */
	public void build_entreprise(ArrayList<Offre> liste) {

		int i = 0;
		/* Banniere */
		JPanelAvecImagedeFond banniere = new JPanelAvecImagedeFond("images\\fond2.jpg");
		texte = new JLabel("Gerer mes offres");
		texte.setHorizontalAlignment(SwingConstants.CENTER);
		texte.setVerticalAlignment(SwingConstants.CENTER);
		texte.setFont(policeTimesRoman);
		banniere.setLayout(new BorderLayout());
		banniere.add(texte, BorderLayout.CENTER);
		banniere.add(vide, BorderLayout.WEST);
		JButton retour = new JButton("Retour");
		boutonPanel.add(retour);
		banniere.add(boutonPanel, BorderLayout.EAST);
		boutonPanel.setOpaque(false);
		vide.setOpaque(false);
		vide.setPreferredSize(new Dimension(85, 125));
		this.add(banniere);
		
		for (Offre ofr : liste) {

			this.add(new Gerer_offre_entreprise(liste.get(i)));
			i++;
		}

		if (liste.size() <= 2)
			this.setLayout(new GridLayout(4, 1, 5, 5));
		else
			this.setLayout(new GridLayout(i + 1, 1, 5, 5));
		retour.addActionListener((new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {
				Fenetre.cardLayout.show(Fenetre.mainPanel, "level_1");

			}
		}));
	}
}
