package IHM;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

import DAO.DomaineDAO;
import DAO.EntrepriseDAO;
import DAO.EtudiantDAO;
import DAO.OffreDAO;
import DAO.StageDAO;
import Objet.Etudiant;
import Objet.Stage;

public class Choix_candidat_Entreprise extends JPanel{

	public Image ImageAffiche;
	public String nomImage;
	
	protected JPanel infoStage = new JPanel();
	protected JPanel panelBouton = new JPanel();
	
	public BorderLayout layout = new BorderLayout();
	public Font police = new Font (" TimesRoman", Font.BOLD,20);
	
	public JLabel titre = new JLabel();
	public JLabel boite = new JLabel();
	public JLabel Ldomaine = new JLabel();
	
	
	public JButton selectionner = new JButton("Voir sa candidature");
	public JLabel labelinfoStage = new JLabel("En attente");
	public JLabel LabelAffiche ;
	public BorderLayout border = new BorderLayout();
	
	public Choix_candidat_Entreprise(final Stage stage){
		super();
		
		
		EtudiantDAO etudDAO = new EtudiantDAO();
		
		Etudiant etudiant = etudDAO.find(stage.getIdEtudiant());
		
		nomImage = "images//candidat.png";
		ImageIcon ImageAfficheFilm = new ImageIcon(nomImage);
		ImageAffiche =  scaleImage(ImageAfficheFilm.getImage(), 160);
		LabelAffiche =  new JLabel(new ImageIcon(ImageAffiche));
		this.add(LabelAffiche,layout.WEST);
	
		
		titre.setText(etudiant.getPrenom()+" "+etudiant.getNom());
		titre.setFont(police);
		
		
		boite.setText("Diplome : Licence 3 ");
		boite.setFont(police);
		
		
		Ldomaine.setText("Statut : "   + stage.getStatut());
		Ldomaine.setFont(police);
		
		selectionner.setText("Voir sa candidature");
		ImageIcon ImageAfficheFilm1 = new ImageIcon(nomImage);
		ImageAffiche =  scaleImage(ImageAfficheFilm1.getImage(), 160);
		LabelAffiche =  new JLabel(new ImageIcon(ImageAffiche));
		
		selectionner.addActionListener(new ActionListener(){

			
			public void actionPerformed(ActionEvent arg0) {
				Fenetre.level_4 = new Fiche_etudiant(stage);
				Fenetre.mainPanel.add(Fenetre.level_4,"level_4");
				Fenetre.cardLayout.show(Fenetre.mainPanel, "level_4");
				
			}
			
		});
		build();
	}
	
	private void build() {
		
			
			this.setLayout(layout);
			this.add(LabelAffiche,layout.WEST);
			
			this.infoStage.setLayout(new GridLayout(3,1,30,-30));
			this.infoStage.add(titre);
			this.infoStage.add(boite);
			this.infoStage.add(Ldomaine);
			
			
			this.titre.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
			this.boite.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
			this.Ldomaine.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
			
			
			this.add(infoStage,layout.CENTER);
			this.add(panelBouton,layout.EAST);
			
			
			this.setBackground(Fenetre.couleurBlanc);
			infoStage.setBackground(Fenetre.couleurBlanc);
			panelBouton.setBackground(Fenetre.couleurBlanc);
			
			//this.panelBouton.setLayout(border);
			this.panelBouton.add(selectionner);
			//this.panelBouton.add(new JButton("salut"));
			
		
		
		
	}

	public static Image scaleImage(Image source, int width, int height) {
	    BufferedImage img = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
	    Graphics2D g = (Graphics2D) img.getGraphics();
	    g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
	    g.drawImage(source, 0, 0, width, height, null);
	    g.dispose();
	    return img;
	}
	
	public static Image scaleImage(Image source, int size) {
	    int width = source.getWidth(null);
	    int height = source.getHeight(null);
	    double f = 0;
	    if (width < height) {//portrait
	        f = (double) height / (double) width;
	        width = (int) (size / f);
	        height = size;
	    } else {//paysage
	        f = (double) width / (double) height;
	        width = size;
	        height = (int) (size / f);
	    }
	    return scaleImage(source, width, height);
	}
	
	}

