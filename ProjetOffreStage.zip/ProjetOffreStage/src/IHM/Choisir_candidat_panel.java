package IHM;

import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JPanel;

import DAO.StageDAO;
import Objet.Offre;
import Objet.Stage;

public class Choisir_candidat_panel extends JPanel{

	
	//Constructeur pour avoir la liste des candidats d'un stage
	 public Choisir_candidat_panel(Offre offre){
		 this.setBackground(new Color(187, 222, 251));
			   
		 int i=0;
		 StageDAO stagDAO = new StageDAO();
		 ArrayList<Stage> list_stage = (ArrayList<Stage>)stagDAO.getAll_stage_by_offre(offre.getId());
		ChoixStageJPanel choix = new ChoixStageJPanel(offre);
		choix.selectionner.setText("Retourner aux offres");
		this.add(choix);
		 for (Stage stag : list_stage){
			   
			   this.add(new Choix_candidat_Entreprise(stag));
			   i++;
		   }
		   
		   if(list_stage.size()<=2)
		   this.setLayout(new GridLayout(4, 1, 5, 5));
		   else
			   this.setLayout(new GridLayout(i+1, 1, 5, 5));

		 
		 choix.selectionner.addActionListener(new ActionListener(){

			
			public void actionPerformed(ActionEvent arg0) {
				Fenetre.cardLayout.show(Fenetre.mainPanel, "level_2");
				
			}
			 
		 });
			}
}
