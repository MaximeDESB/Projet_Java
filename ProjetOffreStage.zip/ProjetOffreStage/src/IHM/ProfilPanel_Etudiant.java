package IHM;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.filechooser.FileNameExtensionFilter;

import Autre.Filtre_FileChooser;
import Autre.Md5;
import DAO.*;
import Objet.*;

/* Classe profil, elle dispose de nombreuse fonctionalit�s */

public class ProfilPanel_Etudiant extends JPanel {

	Font policeTimesRoman = new Font(" TimesRoman ", Font.BOLD, 15);

	public JPanelAvecImagedeFond boutonPanel = new JPanelAvecImagedeFond(
			"images\\fond2.jpg", 801);
	public JPanel info = new JPanel();
	public JPanel panelReservation = new JPanel();

	JPanel panelNom = new JPanel();
	JPanel panelPrenom = new JPanel();
	JPanel panelAdresse = new JPanel();
	JPanel panelLogin = new JPanel();
	JPanel panelMdp = new JPanel();
	JPanel panelEmail = new JPanel();
	JPanel panelVille = new JPanel();
	JPanel p1 = new JPanel();
	JPanel p2 = new JPanel();
	JPanel p3 = new JPanel();
	JPanel p4 = new JPanel();

	JTextField texfieldNom;
	JTextField texfieldPrenom;
	JTextField texfieldAdresse;
	JTextField texfieldVille;
	JTextField texfieldEmail;
	JTextField texfieldPseudo;
	JTextField texfieldMdp;

	JButton quitter = new JButton(new ImageIcon("images//retour.png"));
	JButton modifier = new JButton(new ImageIcon("images//modifier_profil.png"));
	JButton postulation = new JButton(new ImageIcon(
			"images//voir_postulation.png"));
	JButton cv = new JButton(new ImageIcon("images//cv.png"));

	JLabel Nom = new JLabel("Nom 	: ");
	JLabel Prenom = new JLabel("Prenom 	: ");
	JLabel Adresse = new JLabel("Adresse	 : ");
	JLabel Ville = new JLabel("Ville	 : ");
	JLabel login = new JLabel("Pseudo	 : ");
	JLabel Email = new JLabel("Email 	: ");
	JLabel Mdp = new JLabel("Mot de passe 	: ");

	JLabel Nom1;
	JLabel Prenom1;
	JLabel Login1;
	JLabel Adresse1;
	JLabel Ville1;
	JLabel Email1;
	JLabel Mdp1;

	EntrepriseDAO entrDAO = new EntrepriseDAO();
	EtudiantDAO etudDAO = new EtudiantDAO();
	AdresseDAO adreDAO = new AdresseDAO();
	SecuriteDAO secuDAO = new SecuriteDAO();

	Securite securiteLog;
	Adresse adresseLog;

	Md5 md5 = new Md5();
	boolean flag = true;

	String prenom;
	String nom;
	String email;
	String testMDP;
	int idSecurite;
	int idAdresse;

	public Image ImageAffiche;
	public String nomImage;
	ProfilPanel_Etudiant me;
	int nbResevation;

	public ProfilPanel_Etudiant(String prenom, String nom, String email,
			int idAdresse, int idSecurite) {

		super();
		me = this;

		this.prenom = prenom;
		this.nom = nom;
		this.email = email;
		this.idSecurite = idSecurite;
		this.idAdresse = idAdresse;

		Nom1 = new JLabel(nom);
		Prenom1 = new JLabel(prenom);

		securiteLog = secuDAO.find(idSecurite);
		adresseLog = adreDAO.find(idAdresse);

		/* Les labels sont construit en fonction du client connect� */
		Login1 = new JLabel(securiteLog.getLogin());
		Adresse1 = new JLabel(adresseLog.getRue());
		Ville1 = new JLabel(adresseLog.getVille());
		Login1 = new JLabel(securiteLog.getLogin());
		Email1 = new JLabel(email);
		Mdp1 = new JLabel("~Crypt�~");

		this.setLayout(new GridLayout(2, 1));

		this.add(info);// premier panel prinpal
		this.add(boutonPanel); // second
		info.setBackground(new Color(187, 222, 251));

		this.boutonPanel.setLayout(new GridLayout(1, 4));

		p1.add(quitter);
		p2.add(modifier);
		p3.add(postulation);
		p4.add(cv);

		boutonPanel.add(p1);
		boutonPanel.add(p2);
		boutonPanel.add(p3);
		boutonPanel.add(p4);

		p1.setOpaque(false);
		p2.setOpaque(false);
		p3.setOpaque(false);
		p4.setOpaque(false);

		this.panelNom.setBackground(Color.white);
		this.panelPrenom.setBackground(Color.white);
		this.panelAdresse.setBackground(Color.white);
		this.panelEmail.setBackground(Color.white);
		this.panelVille.setBackground(Color.white);
		this.panelMdp.setBackground(Color.white);
		this.panelLogin.setBackground(Color.white);

		this.panelReservation.setBackground(Color.white);

		quitter.setText("Quitter");
		modifier.setText("Modifier");

		postulation.setText("Voir mes candidatures");

		cv.setText("Ajouter un CV");

		cv.setVerticalTextPosition(SwingConstants.TOP);
		cv.setHorizontalTextPosition(SwingConstants.CENTER);

		quitter.setVerticalTextPosition(SwingConstants.TOP);
		quitter.setHorizontalTextPosition(SwingConstants.CENTER);

		modifier.setVerticalTextPosition(SwingConstants.TOP);
		modifier.setHorizontalTextPosition(SwingConstants.CENTER);

		postulation.setVerticalTextPosition(SwingConstants.TOP);
		postulation.setHorizontalTextPosition(SwingConstants.CENTER);

		cv.setVerticalAlignment(SwingConstants.CENTER);

		panelReservation.setLayout(new GridLayout(1, 5));

		/*
		 * Il pourra modifier ses information grace a ces textfield qui on pour
		 * valeur par defaut les valeurs initiales des parametres du compte pour
		 * facilit� la modification
		 */

		texfieldNom = new JTextField(nom);
		texfieldPrenom = new JTextField(prenom);
		texfieldAdresse = new JTextField(adresseLog.getRue());
		texfieldVille = new JTextField(adresseLog.getVille());
		texfieldEmail = new JTextField(email);
		texfieldPseudo = new JTextField(securiteLog.getLogin());
		texfieldMdp = new JPasswordField("********");

		build();

	}

	public void build() {

		/*
		 * Le panel information est compos� des 8 informations Client Nom,
		 * Prenom, Pseudo, Mot de Passe, Adresse , Ville et Email , et
		 * toutikuanti le numero de son cellulaire (#jamaisansmonGSM)
		 * 
		 * Chaque information possede un panel qui contient 2 labels affichant
		 * respectivement le type d'information et sa valeur
		 */

		this.info.setLayout(new GridLayout(7, 1, 1, 1));

		this.panelNom.add(Nom);
		Nom.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		Nom.setFont(policeTimesRoman);
		this.panelNom.add(Nom1);
		this.panelNom.setLayout(new GridLayout(1, 2));
		this.info.add(panelNom);

		this.panelPrenom.add(Prenom);
		Prenom.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		Prenom.setFont(policeTimesRoman);
		this.panelPrenom.add(Prenom1);
		this.panelPrenom.setLayout(new GridLayout(1, 2));
		Prenom.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		this.info.add(panelPrenom);

		this.panelLogin.add(login);
		login.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		login.setFont(policeTimesRoman);
		this.panelLogin.add(Login1);
		this.panelLogin.setLayout(new GridLayout(1, 2));
		this.info.add(panelLogin);

		this.panelAdresse.add(Adresse);
		Adresse.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		Adresse.setFont(policeTimesRoman);
		this.panelAdresse.add(Adresse1);
		this.panelAdresse.setLayout(new GridLayout(1, 2));
		this.info.add(panelAdresse);

		this.panelMdp.add(Mdp);
		Mdp.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		Mdp.setFont(policeTimesRoman);
		this.panelMdp.add(Mdp1);
		this.panelMdp.setLayout(new GridLayout(1, 2));
		this.info.add(panelMdp);

		this.panelEmail.add(Email);
		Email.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		Email.setFont(policeTimesRoman);
		this.panelEmail.add(Email1);
		this.panelEmail.setLayout(new GridLayout(1, 2));
		this.info.add(panelEmail);

		this.panelVille.add(Ville);
		Ville.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
		Ville.setFont(policeTimesRoman);
		this.panelVille.add(Ville1);
		this.panelVille.setLayout(new GridLayout(1, 2));
		this.info.add(panelVille);

		/** Boutons et Actions **/

		// Pour revenir a la page d'acceuil
		this.quitter.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Fenetre.cardLayout.show(Fenetre.mainPanel, "level_1");
			}
		});

		postulation.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {
				if (Fenetre.levelScroll != null) {
					Fenetre.cardLayout.show(Fenetre.mainPanel, "level_scroll");
				} else {
					StageDAO stagDAO = new StageDAO();
					ArrayList<Stage> liste_stage = (ArrayList<Stage>) stagDAO
							.getAll_stage_by_etudiant(Fenetre.getEtudiantLog()
									.getId());
					Fenetre.levelScroll = new JScrollPane(new ConsulterPanel(
							liste_stage, "a"));
					Fenetre.mainPanel.add(Fenetre.levelScroll, "level_scroll");
					Fenetre.cardLayout.show(Fenetre.mainPanel, "level_scroll");
				}
			}

		});
		/* Pour modifier ses infos client via 2 etapes */

		modifier.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {

				/*
				 * Etape 1 : Modifier : les labels contenant les infos sont
				 * supprim�es et remplacer par des textfields contenant les
				 * memes infos
				 */

				if (flag) {

					panelNom.remove(Nom1);
					panelNom.add(texfieldNom);

					panelPrenom.remove(Prenom1);
					panelPrenom.add(texfieldPrenom);

					panelLogin.remove(Login1);
					panelLogin.add(texfieldPseudo);

					panelAdresse.remove(Adresse1);
					panelAdresse.add(texfieldAdresse);

					panelMdp.remove(Mdp1);
					panelMdp.add(texfieldMdp);

					panelEmail.remove(Email1);
					panelEmail.add(texfieldEmail);

					panelVille.remove(Ville1);
					panelVille.add(texfieldVille);

					testMDP = texfieldMdp.getText();

					modifier.setText("Enregistrer les modifications");
					flag = false;
					SwingUtilities.updateComponentTreeUI(me);
				}

				/*
				 * 2eme �tape : Enregistrer les modifications : Si les
				 * textfields saisis sont differents des attributs initial du
				 * client , ces meme atribut sont modifi�s , les textifields
				 * sont finalement supprim� pour revenir aux labels affichant
				 * les nouvelles informations
				 */

				else if (!flag) {

					if (!texfieldNom.getText().equals(
							Fenetre.getEtudiantLog().getNom())) {
						Fenetre.getEtudiantLog().setNom(texfieldNom.getText());
						Nom1.setText(texfieldNom.getText());
					}
					panelNom.remove(texfieldNom);
					panelNom.add(Nom1);

					if (prenom != null) {
						if (!texfieldPrenom.getText().equals(
								Fenetre.getEtudiantLog().getPrenom())) {
							Fenetre.getEtudiantLog().setPrenom(
									texfieldPrenom.getText());
							Prenom1.setText(texfieldPrenom.getText());
						}

						panelPrenom.remove(texfieldPrenom);
						panelPrenom.add(Prenom1);
					}

					if (!texfieldPseudo.getText()
							.equals(securiteLog.getLogin())) {
						securiteLog.setLogin(texfieldPseudo.getText());
						Login1.setText(texfieldPseudo.getText());
					}
					panelLogin.remove(texfieldPseudo);
					panelLogin.add(Login1);

					if (!texfieldAdresse.getText().equals(adresseLog.getRue())) {
						adresseLog.setRue(texfieldAdresse.getText());
						Adresse1.setText(texfieldAdresse.getText());
					}
					panelAdresse.remove(texfieldAdresse);
					panelAdresse.add(Adresse1);

					if (!texfieldVille.getText().equals(adresseLog.getVille())) {
						adresseLog.setVille(texfieldVille.getText());
						Ville1.setText(texfieldVille.getText());
					}
					panelVille.remove(texfieldVille);
					panelVille.add(Ville1);

					if (!texfieldEmail.getText().equals(
							Fenetre.getEtudiantLog().getEmail())) {
						Fenetre.getEtudiantLog().setEmail(
								texfieldEmail.getText());
						Email1.setText(texfieldEmail.getText());
					}
					panelEmail.remove(texfieldEmail);
					panelEmail.add(Email1);

					if (!testMDP.equals(texfieldMdp.getText())) {
						md5.pass(texfieldMdp.getText());
						securiteLog.setMdp(md5.getCode());
					}

					panelMdp.remove(texfieldMdp);
					panelMdp.add(Mdp1);

					modifier.setText("Modifier");

					if (prenom != null) {
						etudDAO.update(Fenetre.getEtudiantLog());
						adreDAO.update(adresseLog);
						secuDAO.update(securiteLog);
						flag = true;
						SwingUtilities.updateComponentTreeUI(me);
					}
				}

			}
		});

		cv.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {
				Filtre_FileChooser mft = new Filtre_FileChooser(
						new String[] { "pdf" }, "les fichiers pdf (*.pdf)");

				FileNameExtensionFilter filter = new FileNameExtensionFilter(
						"Fichiers pdf.", "pdf");

				JFileChooser choix = new JFileChooser();
				int retour = choix.showOpenDialog(me);

				choix.addChoosableFileFilter(filter);
				choix.setFileFilter(filter);
				choix.setAcceptAllFileFilterUsed(false);

				if (retour == JFileChooser.APPROVE_OPTION) {
					// un fichier a �t� choisi (sortie par OK)
					// nom du fichier choisi

					String source = new String();
					try {
						
					source = choix.getSelectedFile().getAbsolutePath();
					String dest = "cv_etudiant//cv__de_"
							+ Fenetre.getEtudiantLog().getNom() + ".pdf";
					
					if (source.charAt(source.length() - 3) == 'p'
							&& source.charAt(source.length() - 2) == 'd'
							&& source.charAt(source.length() - 1) == 'f') {
						Fenetre.getEtudiantLog().setPathCv(
								choix.getSelectedFile().getAbsolutePath());
						EtudiantDAO etudDAO = new EtudiantDAO();
						etudDAO.update_cv(Fenetre.getEtudiantLog());
						Fenetre.getEtudiantLog().setPathCv(dest);
						etudDAO.update_cv(Fenetre.getEtudiantLog());
						copier(new File(source), new File(dest));}
					} 
					catch(NullPointerException e){
						JOptionPane.showMessageDialog(null, "Mauvais format de fichier", "Information",
								JOptionPane.ERROR_MESSAGE);
					}
				
					
					
					
				}
			}
		});

	}

	public static boolean copier(File source, File dest) {
		try (InputStream sourceFile = new java.io.FileInputStream(source);
				OutputStream destinationFile = new FileOutputStream(dest)) {
			// Lecture par segment de 0.5Mo
			byte buffer[] = new byte[512 * 1024];
			int nbLecture;
			while ((nbLecture = sourceFile.read(buffer)) != -1) {
				destinationFile.write(buffer, 0, nbLecture);
			}
		} catch (IOException e) {
			e.printStackTrace();
			return false; // Erreur
		}
		return true; // R�sultat OK
	}

	public static Image scaleImage(Image source, int width, int height) {
		BufferedImage img = new BufferedImage(width, height,
				BufferedImage.TYPE_INT_ARGB);
		Graphics2D g = (Graphics2D) img.getGraphics();
		g.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
				RenderingHints.VALUE_INTERPOLATION_BILINEAR);
		g.drawImage(source, 0, 0, width, height, null);
		g.dispose();
		return img;
	}

	public static Image scaleImage(Image source, int size) {
		int width = source.getWidth(null);
		int height = source.getHeight(null);
		double f = 0;
		if (width < height) {// portrait
			f = (double) height / (double) width;
			width = (int) (size / f);
			height = size;
		} else {// paysage
			f = (double) width / (double) height;
			width = size;
			height = (int) (size / f);
		}
		return scaleImage(source, width, height);
	}

	public String TabtoString(char[] tab) {
		int i = 0;
		String str = new String();
		while (i < tab.length) {
			char a = tab[i];
			str += a;
			i++;

		}
		return str;
	}
}
