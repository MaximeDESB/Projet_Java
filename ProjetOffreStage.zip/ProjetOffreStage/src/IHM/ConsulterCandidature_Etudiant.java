package IHM;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;

import DAO.OffreDAO;
import DAO.StageDAO;
import Objet.Stage;

public class ConsulterCandidature_Etudiant extends ChoixStageJPanel {

	static StageDAO stagDAO = new StageDAO();
	static OffreDAO offrDAO = new OffreDAO();

	JButton annuler;
	JButton effacer;
	JButton accepter;

	int id;
	JPanel pere;

	public ConsulterCandidature_Etudiant(final Stage stage, int i, JPanel p) {

		super(offrDAO.find(stage.getIdOffre()));
		this.id = i;
		pere = p;

		annuler = new JButton("Annuler la candidature");
		effacer = new JButton("Effacer cette demande");
		accepter = new JButton("Annuler ce stage");

		if (stage.getStatut().equals("En attente")) {
			titre.setText("En attente");
			panelBouton.add(annuler);
			titre.setForeground(new Color(255, 128, 0));
		} else if (stage.getStatut().equals("Retenu")) {
			titre.setText("Retenu");
			panelBouton.add(accepter);
			titre.setForeground(new Color(0, 255, 0));
		} else if (stage.getStatut().equals("Refuse")) {
			titre.setText("Refuse");
			panelBouton.add(effacer);
			titre.setForeground(new Color(255, 0, 0));
		} else
			titre.setText("Erreur statut");

		annuler.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {

				stagDAO.delete(stage.getId());
				pere.remove(id);
				SwingUtilities.updateComponentTreeUI(pere);
			}
		});

		accepter.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {

				stagDAO.delete(stage.getId());
				pere.remove(id);
				SwingUtilities.updateComponentTreeUI(pere);
			}

		});
		
		effacer.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {

				stagDAO.delete(stage.getId());
				pere.remove(id);
				SwingUtilities.updateComponentTreeUI(pere);
			}

		});

		Ldomaine.setText(offrDAO.find(stage.getIdOffre()).getNomOffre());

		selectionner.setText("Voir les details");
		selectionner.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent arg0) {
				JPanelOffre joffre = new JPanelOffre(offrDAO.find(stage.getIdOffre()));
				joffre.panelBouton.remove(joffre.postuler);
				Fenetre.level_3 = joffre;
				Fenetre.mainPanel.add(Fenetre.level_3, "level 3");
				Fenetre.cardLayout.show(Fenetre.mainPanel, "level 3");
			}
		});
	}

}
