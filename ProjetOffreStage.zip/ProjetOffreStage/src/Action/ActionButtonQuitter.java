package Action;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;

import IHM.Fenetre;

public class ActionButtonQuitter extends AbstractAction {

	public void actionPerformed(ActionEvent arg0) {
		
		
		Fenetre.cardLayout.show(Fenetre.mainPanel, "level_1");

		
	}

}
