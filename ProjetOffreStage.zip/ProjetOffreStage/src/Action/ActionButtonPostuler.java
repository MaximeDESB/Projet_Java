package Action;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.JOptionPane;

import IHM.Fenetre;
import Objet.Etudiant;
import Objet.Offre;

public class ActionButtonPostuler extends AbstractAction {

	Offre offre;
	Etudiant log;
	String s;
	public ActionButtonPostuler(Offre o, String motivation){
	this.offre = o;
	this.log = Fenetre.getEtudiantLog();
	this.s = motivation;
	}
	
	public void actionPerformed(ActionEvent arg0) {
		
		if(log.postuler(offre,s)){
			JOptionPane.showMessageDialog(null,
					"Votre candidature a bien �t� pris en compte",
					"Information",
					JOptionPane.INFORMATION_MESSAGE);
			Fenetre.cardLayout.show(Fenetre.mainPanel, "Acceuil_log");
		}
		else{
			JOptionPane.showMessageDialog(null,
					"Vous avez deja postuler pour cette offre",
					"Information",
					JOptionPane.INFORMATION_MESSAGE);
		}
		
	}

}
