package Action;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;

import IHM.Fenetre;
import IHM.Acceuil.Acceuil_unlog;

public class ActionButtonDeco extends AbstractAction{

	public void actionPerformed(ActionEvent arg0) {
		Fenetre.getFrame.dispose();
		new Acceuil_unlog();
		
	}

	
	
}
