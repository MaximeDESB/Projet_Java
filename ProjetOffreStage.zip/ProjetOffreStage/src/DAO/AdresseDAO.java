package DAO;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

import Autre.Connexion;
import Objet.*;

public class AdresseDAO implements DAO<Adresse> {

	Connection con;

	final String create = "INSERT into adresse (rue, ville) VALUES ( ? , ?);";
	final String update = "UPDATE adresse SET rue=?, ville=? WHERE id=?;";
	final String delete = "DELETE FROM adresse WHERE id=?;";
	final String find = "SELECT * FROM adresse WHERE id = ?;";
	final String find_id = "SELECT id FROM adresse WHERE rue = ? AND ville = ?;";
	final String getAll = "SELECT * FROM adresse;";

	public AdresseDAO() {

		con = Connexion.connect();
	}

	public Adresse find(int id) {
		Adresse ad = new Adresse();
		PreparedStatement stat = null;
		try {
			stat = (PreparedStatement) con.prepareStatement(find);
			stat.setInt(1, id);
			ResultSet rs = stat.executeQuery();

			if (rs.next()) {
				ad = new Adresse(id, rs.getString("rue"), rs.getString("ville"));
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
		return ad;
	}

	public void create(Adresse obj) {
		PreparedStatement stat = null;
		try {
			stat = (PreparedStatement) con.prepareStatement(create);
			stat.setString(1, obj.getRue());
			stat.setString(2, obj.getVille());
			stat.execute();

			stat = (PreparedStatement) con.prepareStatement(find_id);
			stat.setString(1, obj.getRue());
			stat.setString(2, obj.getVille());
			ResultSet rs = stat.executeQuery();

			if (rs.next()) {
				obj.setId(rs.getInt("id"));
			}

		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
	}

	public void update(Adresse obj) {
		PreparedStatement stat = null;
		try {
			stat = (PreparedStatement) con.prepareStatement(update);
			stat.setString(1, obj.getRue());
			stat.setString(2, obj.getVille());
			stat.setInt(3, obj.getId());
			stat.executeUpdate();
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
	}

	public void delete(int id) {
		PreparedStatement stat = null;
		try {
			stat = (PreparedStatement) con.prepareStatement(delete);
			stat.setInt(1, id);
			stat.execute();
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
	}

	public List<Adresse> getAll() {
		List<Adresse> liste = null;
		PreparedStatement stat = null;
		try {
			liste = new ArrayList<Adresse>();
			stat = (PreparedStatement) con.prepareStatement(getAll);
			ResultSet rs = stat.executeQuery();

			while (rs.next()) {
				Adresse ad = new Adresse(rs.getInt("id"), rs.getString("rue"), rs.getString("ville"));
				liste.add(ad);
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
		return liste;
	}
}
