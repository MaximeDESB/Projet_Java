package DAO;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

import Autre.Connexion;
import Objet.*;

public class DomaineDAO implements DAO<Domaine> {

	Connection con;

	final String create = "INSERT into domaine (nom) VALUES ( ?);";
	final String update = "UPDATE domaine SET nom=? WHERE id=?;";
	final String delete = "DELETE FROM domaine WHERE id=?;";
	final String find = "SELECT * FROM domaine WHERE id = ?;";
	final String find_id = "SELECT id FROM domaine WHERE nom = ?;";
	final String getAll = "SELECT * FROM domaine;";

	public DomaineDAO() {
		// connexion avec BDD
		con = Connexion.connect();
	}

	public Domaine find(int id) {
		Domaine ad = new Domaine();
		PreparedStatement stat = null;
		try {
			stat = (PreparedStatement) con.prepareStatement(find);
			stat.setInt(1, id);
			ResultSet rs = stat.executeQuery();

			if (rs.next()) {
				ad = new Domaine(id, rs.getString("nom"));
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
		return ad;
	}

	public int find_id(String nom) {
		Domaine ad = new Domaine();
		PreparedStatement stat = null;
		try {
			stat = (PreparedStatement) con.prepareStatement(find_id);
			stat.setString(1, nom);
			ResultSet rs = stat.executeQuery();

			if (rs.next()) {
				ad = new Domaine(rs.getInt("id"), nom);
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
		return ad.getId();
	}

	public void create(Domaine obj) {
		PreparedStatement stat = null;
		try {
			stat = (PreparedStatement) con.prepareStatement(create);
			stat.setString(1, obj.getNom());
			stat.execute();
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
	}

	public void update(Domaine obj) {
		PreparedStatement stat = null;
		try {
			stat = (PreparedStatement) con.prepareStatement(update);
			stat.setString(1, obj.getNom());
			stat.setInt(2, obj.getId());
			stat.executeUpdate();
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
	}

	public void delete(int id) {
		PreparedStatement stat = null;
		try {
			stat = (PreparedStatement) con.prepareStatement(delete);
			stat.setInt(1, id);
			stat.execute();
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
	}

	public List<Domaine> getAll() {
		List<Domaine> liste = null;
		PreparedStatement stat = null;
		try {
			liste = new ArrayList<Domaine>();
			stat = (PreparedStatement) con.prepareStatement(getAll);
			ResultSet rs = stat.executeQuery();

			while (rs.next()) {
				Domaine ad = new Domaine(rs.getInt("id"), rs.getString("nom"));
				liste.add(ad);
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
		return liste;
	}
}
