package DAO;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

import Autre.Connexion;
import Objet.Offre;

public class OffreDAO implements DAO<Offre> {

	Connection con;

	final String create = "INSERT into offre (idDomaine, nomOffre, dateDebut, duree, description, "
			+ "idEntreprise) VALUES (?,?,?,?,?,?);";
	final String update = "UPDATE offre SET idDomaine=?, nomOffre=?, dateDebut=?, duree=?,"
			+ " description=?, idEntreprise=? WHERE id=?;";
	final String delete = "DELETE FROM offre WHERE id=?;";
	final String find = "SELECT * FROM offre WHERE id = ?;";
	final String getAll = "SELECT * FROM offre;";
	final String getAll_Entreprise = "SELECT * FROM offre WHERE idEntreprise=?;";

	public OffreDAO() {
		// connexion avec BDD
		con = Connexion.connect();
	}

	public Offre find(int id) {
		Offre e = null;
		PreparedStatement stat = null;
		try {
			stat = (PreparedStatement) con.prepareStatement(find);
			stat.setInt(1, id);
			ResultSet rs = stat.executeQuery();

			if (rs.next()) {
				e = new Offre(rs.getInt("idDomaine"), rs.getString("nomOffre"), rs.getDate("dateDebut"),
						rs.getInt("duree"), rs.getString("description"), rs.getInt("idEntreprise"));
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
		return e;
	}

	public void create(Offre obj) {
		PreparedStatement stat = null;
		try {
			stat = (PreparedStatement) con.prepareStatement(create);
			stat.setInt(1, obj.getIdDomaine());
			stat.setString(2, obj.getNomOffre());
			stat.setDate(3, new java.sql.Date(obj.getDateDebut().getTime()));
			stat.setInt(4, obj.getDuree());
			stat.setString(5, obj.getDescription());
			stat.setInt(6, obj.getIdEntreprise());
			stat.execute();
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
	}

	public void update(Offre obj) {
		PreparedStatement stat = null;
		try {
			stat = (PreparedStatement) con.prepareStatement(update);
			stat.setInt(1, obj.getIdDomaine());
			stat.setString(2, obj.getNomOffre());
			stat.setDate(3, obj.getDateDebut());
			stat.setInt(4, obj.getDuree());
			stat.setString(5, obj.getDescription());
			stat.setInt(6, obj.getIdEntreprise());
			stat.setInt(7, obj.getId());
			stat.executeUpdate();
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
	}

	public void delete(int id) {
		PreparedStatement stat = null;
		try {
			stat = (PreparedStatement) con.prepareStatement(delete);
			stat.setInt(1, id);
			stat.execute();
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
	}

	public List<Offre> getAll() {
		List<Offre> liste = null;
		PreparedStatement stat = null;
		try {
			liste = new ArrayList<Offre>();
			stat = (PreparedStatement) con.prepareStatement(getAll);
			ResultSet rs = stat.executeQuery();

			while (rs.next()) {
				Offre ad = new Offre(rs.getInt("id"), rs.getInt("idDomaine"), rs.getString("nomOffre"),
						rs.getDate("dateDebut"), rs.getInt("duree"), rs.getString("description"),
						rs.getInt("idEntreprise"));
				liste.add(ad);
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
		return liste;
	}

	public List<Offre> getAll_Entreprise(int idEntreprise) {
		List<Offre> liste = null;
		PreparedStatement stat = null;

		try {
			liste = new ArrayList<Offre>();
			stat = (PreparedStatement) con.prepareStatement(getAll_Entreprise);
			stat.setInt(1, idEntreprise);
			ResultSet rs = stat.executeQuery();

			while (rs.next()) {
				Offre ad = new Offre(rs.getInt("id"), rs.getInt("idDomaine"), rs.getString("nomOffre"),
						rs.getDate("dateDebut"), rs.getInt("duree"), rs.getString("description"),
						rs.getInt("idEntreprise"));
				liste.add(ad);
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
		return liste;
	}
}