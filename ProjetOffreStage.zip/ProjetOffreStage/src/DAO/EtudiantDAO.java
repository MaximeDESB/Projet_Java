package DAO;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

import Autre.Connexion;
import Objet.Etudiant;

public class EtudiantDAO implements DAO<Etudiant> {

	Connection con;

	final String create = "INSERT into etudiant (nom, prenom, email, idAdresse, idSecurite, nouveauStage,pathCv) "
			+ " VALUES (?,?,?,?,?,?,?);";
	final String update = "UPDATE etudiant SET nom=?,  prenom=?, email=?, idAdresse=?, idSecurite=?, nouveauStage=?"
			+ " WHERE id=?;";
	final String update_cv = "UPDATE etudiant SET pathCv=? WHERE id=?;";
	final String delete = "DELETE FROM etudiant WHERE id=?;";
	final String find = "SELECT * FROM etudiant WHERE id = ?;";
	final String getAll = "SELECT * FROM etudiant;";

	public EtudiantDAO() {
		// connexion avec BDD
		con = Connexion.connect();
	}

	public Etudiant find(int id) {
		Etudiant e = new Etudiant();
		PreparedStatement stat = null;
		try {
			stat = (PreparedStatement) con.prepareStatement(find);
			stat.setInt(1, id);
			ResultSet rs = stat.executeQuery();

			if (rs.next()) {
				e = new Etudiant(id, rs.getString("nom"), rs.getString("prenom"), rs.getString("email"),
						rs.getInt("idAdresse"), rs.getInt("idSecurite"), rs.getString("pathCv"),
						rs.getBoolean("nouveauStage"));
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
		return e;
	}

	public void create(Etudiant obj) {
		PreparedStatement stat = null;
		try {
			stat = (PreparedStatement) con.prepareStatement(create);
			stat.setString(1, obj.getNom());
			stat.setString(2, obj.getPrenom());
			stat.setString(3, obj.getEmail());
			stat.setInt(4, obj.getIdAdresse());
			stat.setInt(5, obj.getIdSecurite());
			stat.setBoolean(6, obj.getNouveauStage());
			stat.setString(7, obj.getPathCv());
			stat.execute();
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
	}

	public void update(Etudiant obj) {
		PreparedStatement stat = null;
		try {
			stat = (PreparedStatement) con.prepareStatement(update);
			stat.setString(1, obj.getNom());
			stat.setString(2, obj.getPrenom());
			stat.setString(3, obj.getEmail());
			stat.setInt(4, obj.getIdAdresse());
			stat.setInt(5, obj.getIdSecurite());
			stat.setBoolean(6, obj.getNouveauStage());
			stat.setInt(7, obj.getId());
			stat.executeUpdate();
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
	}

	public void update_cv(Etudiant obj) {
		PreparedStatement stat = null;
		try {
			stat = (PreparedStatement) con.prepareStatement(update_cv);
			stat.setString(1, obj.getPathCv());
			stat.setInt(2, obj.getId());
			stat.executeUpdate();
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
	}

	public void delete(int id) {
		PreparedStatement stat = null;
		try {
			stat = (PreparedStatement) con.prepareStatement(delete);
			stat.setInt(1, id);
			stat.execute();
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
	}

	public List<Etudiant> getAll() {
		List<Etudiant> liste = null;
		PreparedStatement stat = null;
		try {
			liste = new ArrayList<Etudiant>();
			stat = (PreparedStatement) con.prepareStatement(getAll);
			ResultSet rs = stat.executeQuery();

			while (rs.next()) {
				Etudiant ad = new Etudiant(rs.getInt("id"), rs.getString("nom"), rs.getString("prenom"),
						rs.getString("email"), rs.getInt("idAdresse"), rs.getInt("idSecurite"), rs.getString("pathCv"),
						rs.getBoolean("nouveauStage"));
				liste.add(ad);

			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
		return liste;
	}
}
