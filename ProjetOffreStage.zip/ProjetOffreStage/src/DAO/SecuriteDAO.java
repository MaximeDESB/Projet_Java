package DAO;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

import Autre.Connexion;
import Objet.Securite;

public class SecuriteDAO implements DAO<Securite> {

	Connection con;

	final String create = "INSERT into securite (login, mdp) VALUES (?,?);";
	final String update = "UPDATE securite SET login=?, mdp=? WHERE id=?;";
	final String delete = "DELETE FROM securite WHERE id=?;";
	final String find = "SELECT * FROM securite WHERE id = ?;";

	final String find_it = "SELECT id FROM securite WHERE login =? AND mdp =?;";
	final String getAll = "SELECT * FROM securite;";

	public SecuriteDAO() {
		// connexion avec BDD
		con = Connexion.connect();
	}

	public Securite find(int id) {
		Securite ad = new Securite();
		PreparedStatement stat = null;
		try {
			stat = (PreparedStatement) con.prepareStatement(find);
			stat.setInt(1, id);
			ResultSet rs = stat.executeQuery();

			if (rs.next()) {
				ad = new Securite(id, rs.getString("login"), rs.getString("mdp"));
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
		return ad;
	}

	@SuppressWarnings("resource")
	public void create(Securite obj) {
		PreparedStatement stat = null;
		try {
			stat = (PreparedStatement) con.prepareStatement(create);
			stat.setString(1, obj.getLogin());
			stat.setString(2, obj.getMdp());
			stat.execute();

			stat = (PreparedStatement) con.prepareStatement(find_it);
			stat.setString(1, obj.getLogin());
			stat.setString(2, obj.getMdp());
			ResultSet rs = stat.executeQuery();

			if (rs.next()) {
				obj.setId(rs.getInt("id"));
			}

		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
	}

	public void update(Securite obj) {
		PreparedStatement stat = null;
		try {
			stat = (PreparedStatement) con.prepareStatement(update);
			stat.setString(1, obj.getLogin());
			stat.setString(2, obj.getMdp());
			stat.setInt(3, obj.getId());
			stat.executeUpdate();
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
	}

	public void delete(int id) {
		PreparedStatement stat = null;
		try {
			stat = (PreparedStatement) con.prepareStatement(delete);
			stat.setInt(1, id);
			stat.execute();
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
	}

	public List<Securite> getAll() {
		List<Securite> liste = null;
		PreparedStatement stat = null;
		try {
			liste = new ArrayList<Securite>();
			stat = (PreparedStatement) con.prepareStatement(getAll);
			ResultSet rs = stat.executeQuery();

			while (rs.next()) {
				Securite ad = new Securite(rs.getInt("id"), rs.getString("login"), rs.getString("mdp"));
				liste.add(ad);
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
		return liste;
	}
}
