package DAO;

import java.util.List;

public interface DAO<T> {

	public abstract T find(int id);

	/**
	 * Permet de cr�er une entr�e dans la base de donn�es par rapport � un objet
	 * 
	 * @param obj
	 */
	public abstract void create(T obj);

	/**
	 * Permet de mettre � jour les donn�es d'une entr�e dans la base
	 * 
	 * @param obj
	 */
	public abstract void update(T obj);

	/**
	 * Permet la suppression d'une entr�e de la base
	 * 
	 * @param obj
	 */
	public abstract void delete(int id);

	public abstract List<T> getAll();
}
