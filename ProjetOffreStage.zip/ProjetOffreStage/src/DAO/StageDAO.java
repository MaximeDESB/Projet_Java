package DAO;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

import Autre.Connexion;
import Objet.Stage;

public class StageDAO implements DAO<Stage> {

	Connection con;

	final String create = "INSERT into stage (idEtudiant, idOffre, statut, motivation) VALUES (?,?,?,?);";
	final String update = "UPDATE stage SET idEtudiant=?, idOffre=?, statut=? WHERE id=?;";
	final String update_statut = "UPDATE stage SET statut=? WHERE id=?;";
	final String delete = "DELETE FROM stage WHERE id=?;";
	final String find = "SELECT * FROM stage WHERE id = ?;";
	final String find_double_id = "SELECT * FROM stage WHERE idEtudiant = ? AND idOffre = ?;";
	final String find_offre = "SELECT * FROM stage WHERE idOffre = ?";
	final String find_etudiant = "SELECT * FROM stage WHERE idEtudiant = ?";
	final String getAll = "SELECT * FROM stage;";

	public StageDAO() {
		// connexion avec BDD
		con = Connexion.connect();
	}

	public Stage find_double_id(int idEtudiant, int idOffre) {
		Stage ad = null;
		PreparedStatement stat = null;
		try {
			stat = (PreparedStatement) con.prepareStatement(find_double_id);
			stat.setInt(1, idEtudiant);
			stat.setInt(2, idOffre);
			ResultSet rs = stat.executeQuery();

			if (rs.next()) {
				ad = new Stage(idEtudiant, idOffre, rs.getString("statut"));
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
		return ad;
	}

	public Stage find(int id) {
		Stage ad = new Stage();
		PreparedStatement stat = null;
		try {
			stat = (PreparedStatement) con.prepareStatement(find);
			stat.setInt(1, id);
			ResultSet rs = stat.executeQuery();

			if (rs.next()) {
				ad = new Stage(rs.getInt("idEtudiant"), rs.getInt("idOffre"), rs.getString("statut"));
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
		return ad;
	}

	public void create(Stage obj) {
		PreparedStatement stat = null;
		try {
			stat = (PreparedStatement) con.prepareStatement(create);
			stat.setInt(1, obj.getIdEtudiant());
			stat.setInt(2, obj.getIdOffre());
			stat.setString(3, obj.getStatut());
			stat.setString(4, obj.getMotivation());
			stat.execute();
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
	}

	public void update(Stage obj) {
		PreparedStatement stat = null;
		try {
			stat = (PreparedStatement) con.prepareStatement(update);
			stat.setInt(1, obj.getIdEtudiant());
			stat.setInt(2, obj.getIdOffre());
			stat.setString(3, obj.getStatut());
			stat.setInt(4, obj.getId());
			stat.executeUpdate();
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
	}

	public void update_statut(Stage obj) {
		PreparedStatement stat = null;
		try {
			stat = (PreparedStatement) con.prepareStatement(update_statut);
			stat.setString(1, obj.getStatut());

			stat.executeUpdate();
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
	}

	public void delete(int id) {
		PreparedStatement stat = null;
		try {
			stat = (PreparedStatement) con.prepareStatement(delete);
			stat.setInt(1, id);
			stat.execute();
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
	}

	public List<Stage> getAll() {
		List<Stage> liste = null;
		PreparedStatement stat = null;
		try {
			liste = new ArrayList<Stage>();
			stat = (PreparedStatement) con.prepareStatement(getAll);
			ResultSet rs = stat.executeQuery();

			while (rs.next()) {
				Stage ad = new Stage(rs.getInt("id"), rs.getInt("idEtudiant"), rs.getInt("idOffre"),
						rs.getString("statut"), rs.getString("motivation"));
				liste.add(ad);
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
		return liste;
	}

	public List<Stage> getAll_stage_by_etudiant(int idEtudiant) {
		List<Stage> liste = null;
		PreparedStatement stat = null;
		try {
			liste = new ArrayList<Stage>();
			stat = (PreparedStatement) con.prepareStatement(find_etudiant);
			stat.setInt(1, idEtudiant);
			ResultSet rs = stat.executeQuery();

			while (rs.next()) {
				Stage ad = new Stage(rs.getInt("id"), rs.getInt("idEtudiant"), rs.getInt("idOffre"),
						rs.getString("statut"), rs.getString("motivation"));
				liste.add(ad);
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
		return liste;
	}

	public List<Stage> getAll_stage_by_offre(int idOffre) {
		List<Stage> liste = null;
		PreparedStatement stat = null;
		try {
			liste = new ArrayList<Stage>();
			stat = (PreparedStatement) con.prepareStatement(find_offre);
			stat.setInt(1, idOffre);
			ResultSet rs = stat.executeQuery();

			while (rs.next()) {
				Stage ad = new Stage(rs.getInt("id"), rs.getInt("idEtudiant"), rs.getInt("idOffre"),
						rs.getString("statut"), rs.getString("motivation"));
				liste.add(ad);
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
		return liste;
	}
}
