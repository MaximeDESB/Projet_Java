package DAO;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

import Autre.Connexion;
import Objet.Entreprise;

public class EntrepriseDAO implements DAO<Entreprise> {

	Connection con;

	final String create = "INSERT into entreprise (nom, idAdresse, email, tel, idSecteur, "
			+ "idSecurite) VALUES (?,?,?,?,?,?);";
	final String update = "UPDATE entreprise SET nom=?, idAdresse=?, email=?, tel=?"
			+ ", idSecteur=?, idSecurite=? WHERE id=?;";
	final String delete = "DELETE FROM entreprise WHERE id=?;";
	final String find = "SELECT * FROM entreprise WHERE id = ?;";
	final String find_nom = "SELECT * FROM entreprise WHERE nom = ?";
	final String find_it = "SELECT id FROM entreprise WHERE nom =? AND idAdresse =? AND email=? AND tel=? AND idSecurite =?;";
	final String getAll = "SELECT * FROM entreprise;";

	public EntrepriseDAO() {
		// connexion avec BDD
		con = Connexion.connect();
	}

	public Entreprise find(int id) {
		Entreprise e = new Entreprise();
		PreparedStatement stat = null;
		try {
			stat = (PreparedStatement) con.prepareStatement(find);
			stat.setInt(1, id);
			ResultSet rs = stat.executeQuery();

			if (rs.next()) {
				e = new Entreprise(id, rs.getString("nom"), rs.getInt("idAdresse"), rs.getString("email"),
						rs.getString("tel"), rs.getInt("idSecteur"), rs.getInt("idSecurite"), rs.getString("logo"));
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
		return e;
	}

	public Entreprise find_nom(String nom) {
		Entreprise e = new Entreprise();
		PreparedStatement stat = null;
		try {
			stat = (PreparedStatement) con.prepareStatement(find_nom);
			stat.setString(1, nom);
			ResultSet rs = stat.executeQuery();

			if (rs.next()) {
				e = new Entreprise(rs.getInt("id"), nom, rs.getInt("idAdresse"), rs.getString("email"),
						rs.getString("tel"), rs.getInt("idSecteur"), rs.getInt("idSecurite"), rs.getString("logo"));
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
		return e;
	}

	@SuppressWarnings("resource")
	public void create(Entreprise obj) {
		PreparedStatement stat = null;
		try {
			stat = (PreparedStatement) con.prepareStatement(create);
			stat.setString(1, obj.getNom());
			stat.setInt(2, obj.getIdAdresse());
			stat.setString(3, obj.getEmail());
			stat.setString(4, obj.getTel());
			stat.setInt(5, obj.getIdSecteur());
			stat.setInt(6, obj.getIdSecurite());
			stat.execute();

			stat = (PreparedStatement) con.prepareStatement(find_it);
			stat.setString(1, obj.getNom());
			stat.setInt(2, obj.getIdAdresse());
			stat.setString(3, obj.getEmail());
			stat.setString(4, obj.getTel());
			stat.setInt(5, obj.getIdSecurite());

			ResultSet rs = stat.executeQuery();

			if (rs.next()) {
				obj.setId(rs.getInt("id"));
			}

		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
	}

	public void update(Entreprise obj) {
		PreparedStatement stat = null;
		try {
			stat = (PreparedStatement) con.prepareStatement(update);
			stat.setString(1, obj.getNom());
			stat.setInt(2, obj.getIdAdresse());
			stat.setString(3, obj.getEmail());
			stat.setString(4, obj.getTel());
			stat.setInt(5, obj.getIdSecteur());
			stat.setInt(6, obj.getIdSecurite());
			stat.setInt(7, obj.getId());
			stat.executeUpdate();
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
	}

	public void delete(int id) {
		PreparedStatement stat = null;
		try {
			stat = (PreparedStatement) con.prepareStatement(delete);
			stat.setInt(1, id);
			stat.execute();
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
	}

	public List<Entreprise> getAll() {
		List<Entreprise> liste = null;
		PreparedStatement stat = null;
		try {
			liste = new ArrayList<Entreprise>();
			stat = (PreparedStatement) con.prepareStatement(getAll);
			ResultSet rs = stat.executeQuery();

			while (rs.next()) {
				Entreprise ad = new Entreprise(rs.getInt("id"), rs.getString("nom"), rs.getInt("idAdresse"),
						rs.getString("email"), rs.getString("tel"), rs.getInt("idSecteur"), rs.getInt("idSecurite"),
						rs.getString("logo"));
				liste.add(ad);
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
		return liste;
	}
}
