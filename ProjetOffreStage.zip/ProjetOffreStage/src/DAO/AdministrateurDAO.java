package DAO;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

import Autre.Connexion;
import Objet.*;

public class AdministrateurDAO implements DAO<Administrateur> {

	Connection con;

	final String create = "INSERT into administrateur (idSecurite) VALUES ( ? );";
	final String update = "UPDATE administrateur SET idSecurite=? WHERE id=?;";
	final String delete = "DELETE FROM administrateur WHERE id=?;";
	final String find = "SELECT * FROM administrateur WHERE id = ?;";
	final String getAll = "SELECT * FROM administrateur;";

	public AdministrateurDAO() {

		con = Connexion.connect();
	}

	public void create(Administrateur obj) {
		PreparedStatement stat = null;
		try {
			stat = (PreparedStatement) con.prepareStatement(create);
			stat.setInt(1, obj.getIdSecurite());
			stat.execute();
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
	}

	public void update(Administrateur obj) {
		PreparedStatement stat = null;
		try {
			stat = (PreparedStatement) con.prepareStatement(update);
			stat.setInt(1, obj.getIdSecurite());
			stat.setInt(2, obj.getId());
			stat.executeUpdate();
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
	}

	public void delete(int id) {
		PreparedStatement stat = null;
		try {
			stat = (PreparedStatement) con.prepareStatement(delete);
			stat.setInt(1, id);
			stat.execute();
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
	}

	public Administrateur find(int id) {
		Administrateur ad = new Administrateur();
		PreparedStatement stat = null;
		try {
			stat = (PreparedStatement) con.prepareStatement(find);
			stat.setInt(1, id);
			ResultSet rs = stat.executeQuery();

			if (rs.next()) {
				ad = new Administrateur(id, rs.getInt("idSecurite"));

			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
		return ad;
	}

	public List<Administrateur> getAll() {
		List<Administrateur> liste = null;
		PreparedStatement stat = null;
		try {
			liste = new ArrayList<Administrateur>();
			stat = (PreparedStatement) con.prepareStatement(getAll);
			ResultSet rs = stat.executeQuery();

			while (rs.next()) {
				Administrateur ad = new Administrateur(rs.getInt("id"), rs.getInt("idSecurite"));
				liste.add(ad);
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
		return liste;
	}
}
