package DAO;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

import Autre.Connexion;
import Objet.Secteur;

public class SecteurDAO implements DAO<Secteur> {

	Connection con;

	final String create = "INSERT into secteur (nom) VALUES (?);";
	final String update = "UPDATE secteur SET nom=? WHERE id=?;";
	final String delete = "DELETE FROM secteur WHERE id=?;";
	final String find = "SELECT * FROM secteur WHERE id = ?;";
	final String find_id = "SELECT id FROM secteur WHERE nom = ?;";
	final String getAll = "SELECT * FROM secteur;";

	public SecteurDAO() {
		// connexion avec BDD
		con = Connexion.connect();
	}
	
	public Secteur find(String id) {
		Secteur ad = new Secteur();
		PreparedStatement stat = null;
		try {
			stat = (PreparedStatement) con.prepareStatement(find_id);
			stat.setString(1, id);
			ResultSet rs = stat.executeQuery();

			if (rs.next()) {
				ad = new Secteur(rs.getInt("id"), rs.getString("nom"));
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
		return ad;
	}

	public Secteur find(int id) {
		Secteur ad = new Secteur();
		PreparedStatement stat = null;
		try {
			stat = (PreparedStatement) con.prepareStatement(find);
			stat.setInt(1, id);
			ResultSet rs = stat.executeQuery();

			if (rs.next()) {
				ad = new Secteur(id, rs.getString("nom"));
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
		return ad;
	}

	public void create(Secteur obj) {
		PreparedStatement stat = null;
		try {
			stat = (PreparedStatement) con.prepareStatement(create);
			stat.setString(1, obj.getNom());
			stat.execute();

			stat = (PreparedStatement) con.clientPrepareStatement(find_id);
			stat.setString(1, obj.getNom());
			ResultSet rs = stat.executeQuery();

			if (rs.next()) {
				obj.setId(rs.getInt("id"));
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
	}

	public void update(Secteur obj) {
		PreparedStatement stat = null;
		try {
			stat = (PreparedStatement) con.prepareStatement(update);
			stat.setString(1, obj.getNom());
			stat.setInt(2, obj.getId());
			stat.executeUpdate();
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
	}

	public void delete(int id) {
		PreparedStatement stat = null;
		try {
			stat = (PreparedStatement) con.prepareStatement(delete);
			stat.setInt(1, id);
			stat.execute();
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
	}

	public List<Secteur> getAll() {
		List<Secteur> liste = null;
		PreparedStatement stat = null;
		try {
			liste = new ArrayList<Secteur>();
			stat = (PreparedStatement) con.prepareStatement(getAll);
			ResultSet rs = stat.executeQuery();

			while (rs.next()) {
				Secteur ad = new Secteur(rs.getInt("id"), rs.getString("nom"));
				liste.add(ad);
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			try {
				stat.close();
			} catch (SQLException ex) {
				ex.printStackTrace();
			}
		}
		return liste;
	}
}
